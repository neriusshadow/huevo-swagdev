/**
 * huEVO Games - Unified Game Model
 * Нормализует данные из любых источников к единому формату
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.HuevoGameModels = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  class GameModel {
    constructor(data = {}) {
      this.id = String(data.id || 'game-' + Math.random().toString(36).substr(2, 9));
      this.title = String(data.title || 'Безымянная игра').trim();
      this.description = String(data.description || 'Описание отсутствует.').trim();
      this.thumbnail = data.thumbnail || 'icons/icon128.png';
      this.url = data.url || '#';
      this.embedUrl = data.embedUrl || data.url || '';
      this.source = String(data.source || 'Неизвестный источник');
      this.genre = String(data.genre || 'Казуальные');
      this.rating = typeof data.rating === 'number' ? Math.min(5, Math.max(0, data.rating)) : 4.5;
      this.playersCount = typeof data.playersCount === 'number' ? data.playersCount : 1000;
      this.isEmbeddable = data.isEmbeddable !== undefined ? Boolean(data.isEmbeddable) : true;
      this.controls = data.controls || 'Клавиатура и мышь';
      this.tags = Array.isArray(data.tags) ? data.tags : [];
      this.isFeatured = Boolean(data.isFeatured);
      this.isNew = Boolean(data.isNew);
      this.dateAdded = data.dateAdded || new Date().toISOString();
    }

    /**
     * Форматированное количество игроков в стиле старого VK (с пробелами)
     */
    getFormattedPlayers() {
      return this.playersCount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' игроков';
    }

    /**
     * Текстовое представление звездного рейтинга (★★★★☆)
     */
    getStarsString() {
      const fullStars = Math.round(this.rating);
      return '★'.repeat(fullStars) + '☆'.repeat(Math.max(0, 5 - fullStars));
    }

    /**
     * Безопасная проверка: можно ли встроить игру во фрейм
     */
    canEmbed() {
      return Boolean(this.isEmbeddable && this.embedUrl && this.embedUrl.startsWith('http'));
    }

    toJSON() {
      return {
        id: this.id,
        title: this.title,
        description: this.description,
        thumbnail: this.thumbnail,
        url: this.url,
        embedUrl: this.embedUrl,
        source: this.source,
        genre: this.genre,
        rating: this.rating,
        playersCount: this.playersCount,
        isEmbeddable: this.isEmbeddable,
        controls: this.controls,
        tags: this.tags,
        isFeatured: this.isFeatured,
        isNew: this.isNew,
        dateAdded: this.dateAdded
      };
    }

    static fromJSON(json) {
      return new GameModel(json);
    }
  }

  return {
    GameModel
  };
});
