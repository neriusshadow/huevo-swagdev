/**
 * huEVO Games - Storage Service
 * Кроссбраузерное хранилище (Chrome, Firefox, Safari/localStorage fallback)
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.HuevoStorage = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const KEYS = {
    FAVORITES: 'huevo_games_favorites',
    HISTORY: 'huevo_games_history',
    CACHE: 'huevo_games_cache',
    SETTINGS: 'huevo_games_settings'
  };

  const hasExtensionStorage = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
  const hasBrowserStorage = typeof browser !== 'undefined' && browser.storage && browser.storage.local;

  /**
   * Асинхронное чтение из хранилища
   */
  async function get(key, defaultValue = null) {
    try {
      if (hasExtensionStorage) {
        return new Promise((resolve) => {
          chrome.storage.local.get([key], (result) => {
            if (chrome.runtime && chrome.runtime.lastError) {
              console.warn('[huEVO Games Storage] chrome.storage error:', chrome.runtime.lastError);
              resolve(getFromLocalStorage(key, defaultValue));
            } else {
              resolve(result[key] !== undefined ? result[key] : defaultValue);
            }
          });
        });
      } else if (hasBrowserStorage) {
        const result = await browser.storage.local.get(key);
        return result[key] !== undefined ? result[key] : defaultValue;
      }
    } catch (e) {
      console.warn('[huEVO Games Storage] Storage exception, falling back to localStorage:', e);
    }
    return getFromLocalStorage(key, defaultValue);
  }

  /**
   * Асинхронная запись в хранилище
   */
  async function set(key, value) {
    try {
      if (hasExtensionStorage) {
        return new Promise((resolve) => {
          chrome.storage.local.set({ [key]: value }, () => {
            resolve(true);
          });
        });
      } else if (hasBrowserStorage) {
        await browser.storage.local.set({ [key]: value });
        return true;
      }
    } catch (e) {
      console.warn('[huEVO Games Storage] Storage set exception:', e);
    }
    setInLocalStorage(key, value);
    return true;
  }

  function getFromLocalStorage(key, defaultValue) {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const raw = window.localStorage.getItem(key);
        if (raw === null) return defaultValue;
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error('[huEVO Games] LocalStorage read failed:', e);
    }
    return defaultValue;
  }

  function setInLocalStorage(key, value) {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        window.localStorage.setItem(key, JSON.stringify(value));
      }
    } catch (e) {
      console.error('[huEVO Games] LocalStorage write failed:', e);
    }
  }

  // --- API для Избранного (Favorites) ---

  async function getFavorites() {
    const list = await get(KEYS.FAVORITES, []);
    return Array.isArray(list) ? list : [];
  }

  async function isFavorite(gameId) {
    const favs = await getFavorites();
    return favs.includes(String(gameId));
  }

  async function toggleFavorite(gameId) {
    const id = String(gameId);
    const favs = await getFavorites();
    const index = favs.indexOf(id);
    let isNowFavorite = false;

    if (index >= 0) {
      favs.splice(index, 1);
      isNowFavorite = false;
    } else {
      favs.unshift(id);
      isNowFavorite = true;
    }

    await set(KEYS.FAVORITES, favs);
    return isNowFavorite;
  }

  // --- API для Истории запусков ---

  async function recordPlay(gameId) {
    const history = await get(KEYS.HISTORY, []);
    const id = String(gameId);
    // Удаляем старую запись об этой игре
    const filtered = history.filter((item) => item.id !== id);
    // Добавляем в начало
    filtered.unshift({
      id,
      timestamp: Date.now()
    });
    // Храним максимум 50 последних запусков
    const trimmed = filtered.slice(0, 50);
    await set(KEYS.HISTORY, trimmed);
    return trimmed;
  }

  async function getRecentGameIds(limit = 10) {
    const history = await get(KEYS.HISTORY, []);
    return (Array.isArray(history) ? history : []).slice(0, limit).map((h) => h.id);
  }

  // --- API для Кэша каталога игр ---

  async function getCachedCatalog() {
    return await get(KEYS.CACHE, null);
  }

  async function setCachedCatalog(catalogData) {
    return await set(KEYS.CACHE, {
      timestamp: Date.now(),
      data: catalogData
    });
  }

  return {
    get,
    set,
    getFavorites,
    isFavorite,
    toggleFavorite,
    recordPlay,
    getRecentGameIds,
    getCachedCatalog,
    setCachedCatalog
  };
});
