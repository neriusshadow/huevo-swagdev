/**
 * huEVO Games - Unified Game API & Registry
 * Центральный сервис поиска, фильтрации и координации источников игр
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('./storage.js'),
      require('./cache.js'),
      require('./models.js'),
      require('./sources/local-catalog-source.js'),
      require('./sources/yandex-adapter.js'),
      require('./sources/poki-adapter.js'),
      require('./sources/crazygames-adapter.js'),
      require('./sources/itchio-adapter.js')
    );
  } else {
    root.HuevoGameAPI = factory(
      root.HuevoStorage,
      root.HuevoCacheManager,
      root.HuevoGameModels,
      root.HuevoLocalCatalogSource,
      root.HuevoYandexAdapter,
      root.HuevoPokiAdapter,
      root.HuevoCrazyGamesAdapter,
      root.HuevoItchIoAdapter
    );
  }
})(typeof self !== 'undefined' ? self : this, function (
  StorageModule,
  CacheModule,
  ModelsModule,
  LocalSourceModule,
  YandexModule,
  PokiModule,
  CrazyGamesModule,
  ItchIoModule
) {
  'use strict';

  const { getFavorites, isFavorite, toggleFavorite, recordPlay, getRecentGameIds } = StorageModule;
  const { CacheManager } = CacheModule;
  const { LocalCatalogSource } = LocalSourceModule;
  const { YandexGamesAdapter } = YandexModule;
  const { PokiAdapter } = PokiModule;
  const { CrazyGamesAdapter } = CrazyGamesModule;
  const { ItchIoAdapter } = ItchIoModule;

  class GameAPI {
    constructor() {
      this.sources = [];
      this.cachedGames = [];
      this.isInitialized = false;

      // Регистрируем встроенные источники
      this.registerSource(new LocalCatalogSource());
      this.registerSource(new YandexGamesAdapter());
      this.registerSource(new PokiAdapter());
      this.registerSource(new CrazyGamesAdapter());
      this.registerSource(new ItchIoAdapter());
    }

    /**
     * Регистрация нового адаптера источника
     */
    registerSource(source) {
      if (!source || !source.name) return;
      this.sources.push(source);
    }

    /**
     * Инициализация и первичная загрузка каталога
     */
    async init(forceRefresh = false) {
      if (this.isInitialized && !forceRefresh && this.cachedGames.length > 0) {
        return this.cachedGames;
      }

      // 1. Проверяем локальный кэш
      if (!forceRefresh) {
        const cached = await CacheManager.getCachedGames();
        // Если кэш содержит старый каталог или не содержит новые игры (krunker, dta6, wormax, supertripland), форсируем обновление
        const isOldCache = cached && cached.games && (
          cached.games.length !== 5 ||
          !cached.games.some((g) => g.id === 'game-minecraft') ||
          !cached.games.some((g) => g.id === 'game-krunker') ||
          !cached.games.some((g) => g.id === 'game-dta6') ||
          !cached.games.some((g) => g.id === 'game-wormax-io') ||
          !cached.games.some((g) => g.id === 'game-supertripland')
        );
        if (cached && cached.games && cached.games.length === 5 && !isOldCache) {
          this.cachedGames = cached.games;
          this.isInitialized = true;
          return this.cachedGames;
        }
      }

      // 2. Загружаем из источников
      await this.fetchFromSources();
      this.isInitialized = true;
      return this.cachedGames;
    }

    /**
     * Сбор игр изо всех зарегистрированных источников
     */
    async fetchFromSources() {
      const allGames = [];
      const seenIds = new Set();

      for (const src of this.sources) {
        try {
          if (await src.isAvailable()) {
            const games = await src.fetchGames();
            for (const game of games) {
              if (!seenIds.has(game.id)) {
                seenIds.add(game.id);
                allGames.push(game);
              }
            }
          }
        } catch (err) {
          console.error(`[huEVO Games API] Error fetching from ${src.name}:`, err);
        }
      }

      this.cachedGames = allGames;
      // Сохраняем в долговременный кэш
      await CacheManager.saveGamesToCache(allGames);
      return allGames;
    }

    /**
     * Поиск и фильтрация каталога
     * @param {Object} filters
     * @param {string} [filters.category] - Жанр (или 'Все игры', 'Новинки', 'Популярные', 'Избранное')
     * @param {string} [filters.source] - Конкретный источник
     * @param {string} [filters.query] - Текст поиска
     * @param {string} [filters.sort] - 'popular' | 'rating' | 'new' | 'title'
     * @param {boolean} [filters.onlyEmbeddable] - Только игры во фрейме
     */
    async getGames(filters = {}) {
      if (!this.isInitialized) {
        await this.init();
      }

      let results = [...this.cachedGames];
      const { category, source, query, sort = 'popular', onlyEmbeddable } = filters;

      // Фильтр по источнику
      if (source && source !== 'all' && source !== 'Все источники') {
        results = results.filter((g) => g.source === source);
      }

      // Фильтр по жанру / спец-категории
      if (category && category !== 'Все игры' && category !== 'all') {
        if (category === 'Новинки') {
          results = results.filter((g) => g.isNew);
        } else if (category === 'Популярные') {
          results = results.filter((g) => g.rating >= 4.7 || g.playersCount > 200000);
        } else if (category === 'Избранное') {
          const favs = await getFavorites();
          results = results.filter((g) => favs.includes(g.id));
        } else {
          results = results.filter((g) => g.genre.toLowerCase() === category.toLowerCase());
        }
      }

      // Фильтр: только безопасный embed
      if (onlyEmbeddable) {
        results = results.filter((g) => g.canEmbed());
      }

      // Полнотекстовый поиск (по названию, описанию, тегам, источнику)
      if (query && query.trim()) {
        const q = query.toLowerCase().trim();
        results = results.filter((g) => {
          return (
            g.title.toLowerCase().includes(q) ||
            g.description.toLowerCase().includes(q) ||
            g.genre.toLowerCase().includes(q) ||
            g.source.toLowerCase().includes(q) ||
            g.tags.some((tag) => tag.toLowerCase().includes(q))
          );
        });
      }

      // Сортировка
      if (sort === 'rating') {
        results.sort((a, b) => b.rating - a.rating);
      } else if (sort === 'new') {
        results.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
      } else if (sort === 'title') {
        results.sort((a, b) => a.title.localeCompare(b.title, 'ru'));
      } else {
        // 'popular' по умолчанию
        results.sort((a, b) => b.playersCount - a.playersCount);
      }

      return results;
    }

    /**
     * Поиск конкретной игры по ID
     */
    async getGameById(id) {
      if (!this.isInitialized) {
        await this.init();
      }
      return this.cachedGames.find((g) => g.id === String(id)) || null;
    }

    /**
     * Список уникальных категорий с количеством игр
     */
    getCategories() {
      const fixedCategories = [
        'Все игры',
        'Новинки',
        'Популярные',
        'Аркады',
        'Головоломки',
        'Экшен',
        'Симуляторы',
        'Гонки',
        'Казуальные',
        'Стратегии',
        'Мультиплеер'
      ];
      return fixedCategories;
    }

    /**
     * Список всех источников с количеством
     */
    getSourcesList() {
      const set = new Set();
      for (const g of this.cachedGames) {
        set.add(g.source);
      }
      return Array.from(set);
    }

    // Проксирование методов хранилища для удобства UI
    async isFavorite(id) {
      return await isFavorite(id);
    }

    async toggleFavorite(id) {
      return await toggleFavorite(id);
    }

    async recordPlay(id) {
      return await recordPlay(id);
    }

    async getRecentGames(limit = 6) {
      const ids = await getRecentGameIds(limit);
      const list = [];
      for (const id of ids) {
        const game = await this.getGameById(id);
        if (game) list.push(game);
      }
      return list;
    }
  }

  return {
    gameAPI: new GameAPI()
  };
});
