/**
 * huEVO Games - CrazyGames Adapter
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('./base-source.js'),
      require('../models.js')
    );
  } else {
    root.HuevoCrazyGamesAdapter = factory(
      root.HuevoBaseSource,
      root.HuevoGameModels
    );
  }
})(typeof self !== 'undefined' ? self : this, function (BaseSourceModule, ModelsModule) {
  'use strict';

  const { BaseGameSource } = BaseSourceModule;

  class CrazyGamesAdapter extends BaseGameSource {
    constructor(options = {}) {
      super('CrazyGames', options);
    }

    async fetchGames() {
      return [];
    }
  }

  return {
    CrazyGamesAdapter
  };
});
