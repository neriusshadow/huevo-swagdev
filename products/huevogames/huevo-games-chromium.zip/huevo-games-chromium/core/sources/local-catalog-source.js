/**
 * huEVO Games - Local Catalog Source
 * Загружает встроенный проверенный каталог игр
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('./base-source.js'),
      require('../models.js')
    );
  } else {
    root.HuevoLocalCatalogSource = factory(
      root.HuevoBaseSource,
      root.HuevoGameModels
    );
  }
})(typeof self !== 'undefined' ? self : this, function (BaseSourceModule, ModelsModule) {
  'use strict';

  const { BaseGameSource } = BaseSourceModule;
  const { GameModel } = ModelsModule;

  class LocalCatalogSource extends BaseGameSource {
    constructor(options = {}) {
      super('Локальный каталог huEVO', options);
      this.cachedGames = null;
    }

    async fetchGames() {
      if (this.cachedGames && this.cachedGames.length > 0) {
        return this.cachedGames;
      }

      try {
        let rawCatalog = null;

        // В среде расширения Chrome / Firefox
        const getUrlFn = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL)
          ? chrome.runtime.getURL.bind(chrome.runtime)
          : (typeof browser !== 'undefined' && browser.runtime && browser.runtime.getURL)
            ? browser.runtime.getURL.bind(browser.runtime)
            : null;

        if (getUrlFn) {
          const url = getUrlFn('data/games-catalog.json');
          const response = await fetch(url);
          if (response.ok) {
            rawCatalog = await response.json();
          }
        }

        // Если не удалось загрузить через runtime
        if (!rawCatalog && typeof fetch !== 'undefined') {
          try {
            const resp = await fetch('data/games-catalog.json');
            if (resp.ok) rawCatalog = await resp.json();
          } catch (e) {
            // ignore
          }
        }

        if (Array.isArray(rawCatalog)) {
          this.cachedGames = rawCatalog.map((item) => new GameModel(item));
          return this.cachedGames;
        }
      } catch (err) {
        console.error('[huEVO Games] Failed to load local catalog:', err);
      }

      return [];
    }
  }

  return {
    LocalCatalogSource
  };
});
