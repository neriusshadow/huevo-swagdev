/**
 * huEVO Games - Base Game Source Adapter
 * Базовый класс для всех источников игр
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.HuevoBaseSource = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  class BaseGameSource {
    constructor(name, options = {}) {
      this.name = name || 'BaseSource';
      this.options = options;
      this.enabled = options.enabled !== undefined ? options.enabled : true;
    }

    /**
     * Проверка доступности источника
     */
    async isAvailable() {
      return this.enabled;
    }

    /**
     * Получение списка игр из источника
     * @returns {Promise<Array<GameModel>>}
     */
    async fetchGames() {
      throw new Error(`fetchGames must be implemented in source ${this.name}`);
    }

    /**
     * Поиск по источнику
     */
    async search(query) {
      const all = await this.fetchGames();
      if (!query || !query.trim()) return all;
      const q = query.toLowerCase().trim();
      return all.filter((game) => {
        return (
          game.title.toLowerCase().includes(q) ||
          game.description.toLowerCase().includes(q) ||
          game.genre.toLowerCase().includes(q) ||
          game.tags.some((t) => t.toLowerCase().includes(q))
        );
      });
    }

    /**
     * Получить конкретную игру по ID
     */
    async getById(id) {
      const all = await this.fetchGames();
      return all.find((g) => g.id === id) || null;
    }
  }

  return {
    BaseGameSource
  };
});
