/**
 * huEVO Games - Yandex Games Adapter
 * Адаптер для интеграции внешнего каталога Яндекс Игр
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('./base-source.js'),
      require('../models.js')
    );
  } else {
    root.HuevoYandexAdapter = factory(
      root.HuevoBaseSource,
      root.HuevoGameModels
    );
  }
})(typeof self !== 'undefined' ? self : this, function (BaseSourceModule, ModelsModule) {
  'use strict';

  const { BaseGameSource } = BaseSourceModule;
  const { GameModel } = ModelsModule;

  class YandexGamesAdapter extends BaseGameSource {
    constructor(options = {}) {
      super('Яндекс Игры', options);
      this.apiEndpoint = options.apiEndpoint || null;
    }

    normalize(item) {
      return new GameModel({
        id: 'ya-' + (item.app_id || item.id),
        title: item.title || item.name,
        description: item.description || 'Игра из каталога Яндекс Игры.',
        thumbnail: item.cover || item.thumbnail || item.icon_url,
        url: item.url || `https://yandex.ru/games/app/${item.app_id || item.id}`,
        embedUrl: item.embed_url || item.url || '',
        source: 'Яндекс Игры',
        genre: item.genre || 'Казуальные',
        rating: typeof item.rating === 'number' ? item.rating : 4.7,
        playersCount: item.players_count || 150000,
        isEmbeddable: Boolean(item.allow_embed),
        controls: item.controls || 'Мышь или клавиатура',
        tags: item.tags || ['Яндекс Игры', 'HTML5']
      });
    }

    async fetchGames() {
      // Возвращаем только игры с официальным разрешением на iframe встраивание
      return [];
    }
  }

  return {
    YandexGamesAdapter
  };
});
