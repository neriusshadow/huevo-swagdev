/**
 * huEVO Games - itch.io Adapter
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('./base-source.js'),
      require('../models.js')
    );
  } else {
    root.HuevoItchIoAdapter = factory(
      root.HuevoBaseSource,
      root.HuevoGameModels
    );
  }
})(typeof self !== 'undefined' ? self : this, function (BaseSourceModule, ModelsModule) {
  'use strict';

  const { BaseGameSource } = BaseSourceModule;

  class ItchIoAdapter extends BaseGameSource {
    constructor(options = {}) {
      super('itch.io', options);
    }

    async fetchGames() {
      return [];
    }
  }

  return {
    ItchIoAdapter
  };
});
