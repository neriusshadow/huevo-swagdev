/**
 * huEVO Games - Poki Adapter
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('./base-source.js'),
      require('../models.js')
    );
  } else {
    root.HuevoPokiAdapter = factory(
      root.HuevoBaseSource,
      root.HuevoGameModels
    );
  }
})(typeof self !== 'undefined' ? self : this, function (BaseSourceModule, ModelsModule) {
  'use strict';

  const { BaseGameSource } = BaseSourceModule;

  class PokiAdapter extends BaseGameSource {
    constructor(options = {}) {
      super('Poki Games', options);
    }

    async fetchGames() {
      return [];
    }
  }

  return {
    PokiAdapter
  };
});
