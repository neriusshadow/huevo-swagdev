/**
 * huEVO Games - Cache Manager
 * Управляет локальным кэшированием каталога в browser.storage / localStorage
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('./storage.js'),
      require('./models.js')
    );
  } else {
    root.HuevoCacheManager = factory(
      root.HuevoStorage,
      root.HuevoGameModels
    );
  }
})(typeof self !== 'undefined' ? self : this, function (StorageModule, ModelsModule) {
  'use strict';

  const { getCachedCatalog, setCachedCatalog } = StorageModule;
  const { GameModel } = ModelsModule;

  // Время жизни кэша: 1 час (3600000 мс)
  const CACHE_TTL_MS = 60 * 60 * 1000;

  class CacheManager {
    constructor(ttlMs = CACHE_TTL_MS) {
      this.ttlMs = ttlMs;
    }

    /**
     * Получить валидные данные из кэша
     * @returns {Promise<Array<GameModel>|null>}
     */
    async getCachedGames() {
      try {
        const cacheEntry = await getCachedCatalog();
        if (!cacheEntry || !cacheEntry.timestamp || !Array.isArray(cacheEntry.data)) {
          return null;
        }

        const age = Date.now() - cacheEntry.timestamp;
        const isExpired = age > this.ttlMs;

        // Восстанавливаем объекты моделей
        const games = cacheEntry.data.map((item) => new GameModel(item));

        return {
          games,
          isExpired,
          ageMs: age,
          timestamp: cacheEntry.timestamp
        };
      } catch (err) {
        console.warn('[huEVO Games Cache] Error reading cache:', err);
        return null;
      }
    }

    /**
     * Записать игры в кэш
     */
    async saveGamesToCache(games) {
      if (!Array.isArray(games)) return false;
      const serializable = games.map((g) => (g.toJSON ? g.toJSON() : g));
      await setCachedCatalog(serializable);
      return true;
    }
  }

  return {
    CacheManager: new CacheManager()
  };
});
