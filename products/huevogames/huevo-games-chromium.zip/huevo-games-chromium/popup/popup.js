/**
 * huEVO Games - Popup Logic
 */

document.addEventListener('DOMContentLoaded', async () => {
  const btnOpenGames = document.getElementById('btn-open-games');
  const btnRefreshCache = document.getElementById('btn-refresh-cache');
  const statTotal = document.getElementById('stat-total-games');
  const statFav = document.getElementById('stat-fav-games');
  const statRecent = document.getElementById('stat-recent-games');
  const recentList = document.getElementById('recent-games-list');

  const { gameAPI } = window.HuevoGameAPI || {};

  // Функция открытия huEVO Игры в активной вкладке или в новой
  function openHuEvoGames(hash = '#/games') {
    const targetUrl = `https://huevo.departament.site/${hash}`;

    if (typeof chrome !== 'undefined' && chrome.tabs) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTab = tabs[0];
        if (activeTab && activeTab.url && activeTab.url.includes('huevo.departament.site')) {
          chrome.tabs.update(activeTab.id, { url: targetUrl });
          window.close();
        } else {
          chrome.tabs.create({ url: targetUrl });
          window.close();
        }
      });
    } else {
      window.open(targetUrl, '_blank');
    }
  }

  btnOpenGames.addEventListener('click', () => {
    openHuEvoGames('#/games');
  });

  if (gameAPI) {
    try {
      await gameAPI.init();
      const allGames = await gameAPI.getGames();
      const favGames = await gameAPI.getGames({ category: 'Избранное' });
      const recentGames = await gameAPI.getRecentGames(5);

      if (statTotal) statTotal.textContent = allGames.length;
      if (statFav) statFav.textContent = favGames.length;
      if (statRecent) statRecent.textContent = recentGames.length;

      if (recentGames.length > 0 && recentList) {
        recentList.innerHTML = recentGames
          .map(
            (g) => `
          <div class="huevo-pop-recent-item" data-id="${g.id}">
            <img class="huevo-pop-recent-thumb" src="${g.thumbnail}" alt="${g.title}" onerror="this.src='../icons/icon48.png'">
            <div class="huevo-pop-recent-title">${g.title}</div>
            <div class="huevo-pop-recent-genre">${g.genre}</div>
          </div>
        `
          )
          .join('');

        recentList.querySelectorAll('.huevo-pop-recent-item').forEach((item) => {
          item.addEventListener('click', () => {
            const id = item.getAttribute('data-id');
            openHuEvoGames(`#/game/${id}`);
          });
        });
      }
    } catch (e) {
      console.error('[huEVO Games Popup] Error loading stats:', e);
    }
  }

  if (btnRefreshCache && gameAPI) {
    btnRefreshCache.addEventListener('click', async () => {
      btnRefreshCache.textContent = 'Обновление...';
      btnRefreshCache.disabled = true;
      try {
        await gameAPI.init(true);
        const all = await gameAPI.getGames();
        if (statTotal) statTotal.textContent = all.length;
        btnRefreshCache.textContent = '✓ Обновлено!';
        setTimeout(() => {
          btnRefreshCache.textContent = '↻ Обновить кэш';
          btnRefreshCache.disabled = false;
        }, 1500);
      } catch (err) {
        btnRefreshCache.textContent = 'Ошибка';
        setTimeout(() => {
          btnRefreshCache.textContent = '↻ Обновить кэш';
          btnRefreshCache.disabled = false;
        }, 1500);
      }
    });
  }
});
