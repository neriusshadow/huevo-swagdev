/**
 * huEVO Games - Service Worker / Background Script
 * Кроссбраузерный фоновый скрипт (Chrome MV3 Service Worker + Firefox MV3 Background)
 */

'use strict';

console.log('[huEVO Games Background] Фоновый сервис запущен');

// Регистрация правил удаления X-Frame-Options для iframe (Wormax.io и др.)
const api = typeof chrome !== 'undefined' ? chrome : (typeof browser !== 'undefined' ? browser : null);

if (api && api.declarativeNetRequest && api.declarativeNetRequest.updateDynamicRules) {
  api.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [100, 101],
    addRules: [
      {
        id: 100,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          responseHeaders: [
            { header: 'X-Frame-Options', operation: 'remove' },
            { header: 'x-frame-options', operation: 'remove' },
            { header: 'Content-Security-Policy', operation: 'remove' },
            { header: 'content-security-policy', operation: 'remove' }
          ]
        },
        condition: {
          urlFilter: '*://*.wormax.io/*',
          resourceTypes: ['sub_frame']
        }
      },
      {
        id: 101,
        priority: 1,
        action: {
          type: 'modifyHeaders',
          responseHeaders: [
            { header: 'X-Frame-Options', operation: 'remove' },
            { header: 'x-frame-options', operation: 'remove' },
            { header: 'Content-Security-Policy', operation: 'remove' },
            { header: 'content-security-policy', operation: 'remove' }
          ]
        },
        condition: {
          urlFilter: '*://wormax.io/*',
          resourceTypes: ['sub_frame']
        }
      }
    ]
  }).catch((err) => console.warn('[huEVO Background] DNR updateDynamicRules:', err));
}

// Fallback для Firefox webRequestBlocking если поддерживается
if (api && api.webRequest && api.webRequest.onHeadersReceived) {
  try {
    api.webRequest.onHeadersReceived.addListener(
      (details) => {
        if (!details.responseHeaders) return;
        const responseHeaders = details.responseHeaders.filter(
          (h) => !['x-frame-options', 'content-security-policy'].includes(h.name.toLowerCase())
        );
        return { responseHeaders };
      },
      { urls: ['*://*.wormax.io/*', '*://wormax.io/*'], types: ['sub_frame'] },
      ['blocking', 'responseHeaders']
    );
  } catch (e) {}
}

// Событие установки или обновления расширения
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener(async (details) => {
    console.log('[huEVO Games Background] Событие onInstalled:', details.reason);

    try {
      // Предварительно прогреваем кэш каталога при установке
      const catalogUrl = chrome.runtime.getURL('data/games-catalog.json');
      const response = await fetch(catalogUrl);
      if (response.ok) {
        const games = await response.json();
        if (Array.isArray(games) && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({
            huevo_games_cache: {
              timestamp: Date.now(),
              data: games
            }
          });
          console.log('[huEVO Games Background] Каталог успешно закэширован, игр:', games.length);
        }
      }
    } catch (err) {
      console.warn('[huEVO Games Background] Ошибка прогрева кэша:', err);
    }
  });
}

// Обработка сообщений от Popup или Content скриптов
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'PING') {
      sendResponse({ status: 'OK', version: '1.0.0' });
      return true;
    }

    if (request.action === 'CLEAR_CACHE') {
      if (chrome.storage && chrome.storage.local) {
        chrome.storage.local.remove(['huevo_games_cache'], () => {
          sendResponse({ success: true });
        });
        return true;
      }
    }
  });
}
