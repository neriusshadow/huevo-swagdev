/**
 * huEVO Games - Catalog View
 * Отображение каталога игр, фильтров, поиска и списка избранного
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('../core/api.js'),
      require('./components.js')
    );
  } else {
    root.HuevoCatalogView = factory(
      root.HuevoGameAPI,
      root.HuevoComponents
    );
  }
})(typeof self !== 'undefined' ? self : this, function (APIModule, ComponentsModule) {
  'use strict';

  const { gameAPI } = APIModule;
  const {
    renderGameCard,
    renderHeaderTabs,
    renderFilterBar,
    renderEmptyState,
    renderLoader
  } = ComponentsModule;

  class CatalogView {
    constructor(containerElement, onNavigate) {
      this.container = containerElement;
      this.onNavigate = onNavigate || (() => {});
      this.currentFilters = {
        category: 'Все игры',
        source: 'all',
        query: '',
        sort: 'popular'
      };
      this.activeTab = 'catalog';
      this.searchTimeout = null;
    }

    async render(initialTab = 'catalog', categoryParam = null) {
      this.activeTab = initialTab;
      if (categoryParam) {
        this.currentFilters.category = categoryParam;
      } else if (initialTab === 'popular') {
        this.currentFilters.category = 'Популярные';
      } else if (initialTab === 'new') {
        this.currentFilters.category = 'Новинки';
      } else if (initialTab === 'favorites') {
        this.currentFilters.category = 'Избранное';
      } else {
        this.currentFilters.category = 'Все игры';
      }

      this.container.innerHTML = `
        <div class="huevo-games-section">
          <div class="huevo-games-header">
            <h1 class="huevo-games-main-title">Игры huEVO</h1>
            <span class="huevo-games-subtitle">Каталог браузерных игр в духе классического интернета</span>
          </div>
          <div id="huevo-games-tabs-container"></div>
          <div id="huevo-games-filters-container"></div>
          <div id="huevo-games-grid-container" class="huevo-games-grid">
            ${renderLoader()}
          </div>
        </div>
      `;

      await gameAPI.init();
      await this.updateTabs();
      this.updateFilters();
      await this.updateGrid();
      this.bindEvents();
    }

    async updateTabs() {
      const tabsContainer = this.container.querySelector('#huevo-games-tabs-container');
      if (!tabsContainer) return;
      const favGames = await gameAPI.getGames({ category: 'Избранное' });
      tabsContainer.innerHTML = renderHeaderTabs(this.activeTab, favGames.length);
    }

    updateFilters() {
      const filtersContainer = this.container.querySelector('#huevo-games-filters-container');
      if (!filtersContainer) return;
      const categories = gameAPI.getCategories();
      const sources = gameAPI.getSourcesList();
      filtersContainer.innerHTML = renderFilterBar(categories, sources, this.currentFilters);
    }

    async updateGrid() {
      const grid = this.container.querySelector('#huevo-games-grid-container');
      if (!grid) return;

      grid.innerHTML = renderLoader();
      const games = await gameAPI.getGames(this.currentFilters);

      if (games.length === 0) {
        grid.innerHTML = renderEmptyState(this.currentFilters.query, this.currentFilters.category);
        const resetBtn = grid.querySelector('#huevo-games-reset-filters');
        if (resetBtn) {
          resetBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.currentFilters = {
              category: 'Все игры',
              source: 'all',
              query: '',
              sort: 'popular'
            };
            this.activeTab = 'catalog';
            this.updateTabs();
            this.updateFilters();
            this.updateGrid();
            this.bindEvents();
          });
        }
        return;
      }

      const favGames = await gameAPI.getGames({ category: 'Избранное' });
      const favIds = new Set(favGames.map((g) => g.id));

      const cardsHtml = games.map((game) => renderGameCard(game, favIds.has(game.id))).join('');
      grid.innerHTML = cardsHtml;
    }

    bindEvents() {
      // 1. Живой поиск
      const searchInput = this.container.querySelector('#huevo-games-search-input');
      if (searchInput) {
        searchInput.addEventListener('input', (e) => {
          clearTimeout(this.searchTimeout);
          this.searchTimeout = setTimeout(() => {
            this.currentFilters.query = e.target.value;
            this.updateGrid();
          }, 120);
        });
      }

      const searchClear = this.container.querySelector('#huevo-games-search-clear');
      if (searchClear) {
        searchClear.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          this.currentFilters.query = '';
          if (searchInput) searchInput.value = '';
          this.updateFilters();
          this.updateGrid();
          this.bindEvents();
        });
      }

      // 2. Сортировка
      const sortSelect = this.container.querySelector('#huevo-games-sort-select');
      if (sortSelect) {
        sortSelect.addEventListener('change', (e) => {
          this.currentFilters.sort = e.target.value;
          this.updateGrid();
        });
      }

      // 3. Фильтр источника
      const sourceSelect = this.container.querySelector('#huevo-games-source-select');
      if (sourceSelect) {
        sourceSelect.addEventListener('change', (e) => {
          this.currentFilters.source = e.target.value;
          this.updateGrid();
        });
      }

      // 4. Клики по пиллам жанров
      const genresList = this.container.querySelector('#huevo-games-genres-list');
      if (genresList) {
        genresList.addEventListener('click', (e) => {
          const pill = e.target.closest('.huevo-games-genre-pill');
          if (!pill) return;
          e.preventDefault();
          e.stopPropagation();

          const cat = pill.getAttribute('data-category');
          this.currentFilters.category = cat;

          genresList.querySelectorAll('.huevo-games-genre-pill').forEach((p) => p.classList.remove('active'));
          pill.classList.add('active');

          this.updateGrid();
        });
      }

      // 5. Клики по верхним вкладкам (переключаются мгновенно на клиенте)
      const tabsContainer = this.container.querySelector('#huevo-games-tabs-container');
      if (tabsContainer) {
        tabsContainer.addEventListener('click', (e) => {
          const link = e.target.closest('a[data-tab-id]');
          if (!link) return;
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();

          const tabId = link.getAttribute('data-tab-id');
          this.activeTab = tabId;

          if (tabId === 'catalog') {
            this.currentFilters.category = 'Все игры';
          } else if (tabId === 'favorites') {
            this.currentFilters.category = 'Избранное';
          } else if (tabId === 'popular') {
            this.currentFilters.category = 'Популярные';
          } else if (tabId === 'new') {
            this.currentFilters.category = 'Новинки';
          }

          this.updateTabs();
          this.updateFilters();
          this.updateGrid();
          this.bindEvents();
        });
      }

      // 6. Клики по кнопке избранного
      const grid = this.container.querySelector('#huevo-games-grid-container');
      if (grid) {
        grid.addEventListener('click', async (e) => {
          const favBtn = e.target.closest('.huevo-games-fav-btn');
          if (!favBtn) return;
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();

          const gameId = favBtn.getAttribute('data-fav-id');
          const isFav = await gameAPI.toggleFavorite(gameId);

          if (isFav) {
            favBtn.classList.add('active');
            favBtn.textContent = '♥';
            favBtn.title = 'Удалить из моих игр';
          } else {
            favBtn.classList.remove('active');
            favBtn.textContent = '♡';
            favBtn.title = 'Добавить в мои игры';
          }

          await this.updateTabs();

          if (this.currentFilters.category === 'Избранное' && !isFav) {
            const card = favBtn.closest('.huevo-games-card');
            if (card) {
              card.style.opacity = '0';
              setTimeout(() => this.updateGrid(), 150);
            }
          }
        });

        // 7. Клик по кнопке "Играть" или карточке игры
        grid.addEventListener('click', (e) => {
          const playLink = e.target.closest('[data-play-id]') || e.target.closest('.huevo-games-title');
          if (!playLink) return;
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();

          const gameId =
            playLink.getAttribute('data-play-id') ||
            playLink.closest('.huevo-games-card').getAttribute('data-game-id');
          if (gameId) {
            this.onNavigate('game', gameId);
          }
        });
      }
    }
  }

  return {
    CatalogView
  };
});
