/**
 * huEVO Games - Game Player View
 * Страница запуска и прохождения игры прямо на сайте huEVO
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('../core/api.js'),
      require('./components.js')
    );
  } else {
    root.HuevoGamePlayerView = factory(
      root.HuevoGameAPI,
      root.HuevoComponents
    );
  }
})(typeof self !== 'undefined' ? self : this, function (APIModule, ComponentsModule) {
  'use strict';

  const { gameAPI } = APIModule;
  const { escapeHtml, renderLoader } = ComponentsModule;

  class GamePlayerView {
    constructor(containerElement, onNavigate) {
      this.container = containerElement;
      this.onNavigate = onNavigate || (() => {});
      this.currentGame = null;
    }

    async render(gameId) {
      this.container.innerHTML = `
        <div class="huevo-games-section huevo-player-section">
          ${renderLoader()}
        </div>
      `;

      const game = await gameAPI.getGameById(gameId);
      if (!game) {
        this.container.innerHTML = `
          <div class="huevo-games-section">
            <div class="huevo-games-empty">
              <div class="huevo-games-empty-icon">⚠️</div>
              <div class="huevo-games-empty-title">Игра не найдена</div>
              <div class="huevo-games-empty-desc">Возможно, игра была перемещена или ссылка устарела.</div>
              <button type="button" class="huevo-games-btn huevo-games-btn-primary" id="huevo-games-back-to-catalog">← Вернуться к каталогу</button>
            </div>
          </div>
        `;
        const backBtn = this.container.querySelector('#huevo-games-back-to-catalog');
        if (backBtn) {
          backBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.onNavigate('catalog');
          });
        }
        return;
      }

      this.currentGame = game;
      await gameAPI.recordPlay(game.id);

      const isFav = await gameAPI.isFavorite(game.id);
      const favText = isFav ? '♥ В моих играх' : '♡ В мои игры';
      const favClass = isFav ? 'huevo-games-btn-fav active' : 'huevo-games-btn-fav';

      const related = (await gameAPI.getGames({ category: game.genre }))
        .filter((g) => g.id !== game.id)
        .slice(0, 4);

      let playUrl = game.embedUrl || game.url;
      if (playUrl && playUrl.startsWith('games/')) {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
          playUrl = chrome.runtime.getURL(playUrl);
        } else if (typeof browser !== 'undefined' && browser.runtime && browser.runtime.getURL) {
          playUrl = browser.runtime.getURL(playUrl);
        }
      }

      this.container.innerHTML = `
        <div class="huevo-games-section huevo-player-section">
          <!-- Навигационная цепочка в стиле старого VK -->
          <div class="huevo-games-nav-trail">
            <a href="#/games" id="huevo-games-back-link" class="huevo-games-back-btn">← Назад к играм</a>
            <span class="huevo-games-trail-sep">/</span>
            <span class="huevo-games-trail-genre">${escapeHtml(game.genre)}</span>
            <span class="huevo-games-trail-sep">/</span>
            <span class="huevo-games-trail-curr"><b>${escapeHtml(game.title)}</b></span>
          </div>

          <!-- Шапка плеера игры -->
          <div class="huevo-player-card-header">
            <div class="huevo-player-left">
              <img class="huevo-player-thumb" src="${escapeHtml(game.thumbnail)}" alt="${escapeHtml(game.title)}" onerror="this.src='icons/icon48.png'">
              <div>
                <h1 class="huevo-player-title">${escapeHtml(game.title)}</h1>
                <div class="huevo-player-sub">
                  <span class="huevo-player-rating" title="Рейтинг: ${game.rating}">${game.getStarsString()} <b>${game.rating}</b></span>
                  <span class="huevo-games-trail-sep">•</span>
                  <span>${game.getFormattedPlayers()}</span>
                  <span class="huevo-games-trail-sep">•</span>
                  <span class="huevo-games-source-badge">${escapeHtml(game.source)}</span>
                </div>
              </div>
            </div>

            <div class="huevo-player-header-actions">
              <button type="button" class="huevo-games-btn ${favClass}" id="huevo-player-fav-btn" title="Добавить в мои игры">${favText}</button>
              <button type="button" class="huevo-games-btn" id="huevo-player-reload-btn" title="Перезагрузить игру">↻ Заново</button>
              <button type="button" class="huevo-games-btn huevo-games-btn-primary" id="huevo-player-fs-btn" title="Развернуть на весь экран">⛶ Во весь экран</button>
            </div>
          </div>

          <!-- Игровое поле: ВСЕГДА запускается на самом сайте huEVO -->
          <div class="huevo-player-stage-wrap" id="huevo-player-stage">
            <div class="huevo-iframe-wrapper" id="huevo-iframe-box">
              <div class="huevo-iframe-loader" id="huevo-iframe-loader">
                <div class="huevo-games-spinner"></div>
                <div>Запуск игры «${escapeHtml(game.title)}»...</div>
              </div>
              <iframe
                id="huevo-game-iframe"
                src="${escapeHtml(playUrl)}"
                title="${escapeHtml(game.title)}"
                tabindex="0"
                frameborder="0"
                scrolling="no"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen; gamepad; pointer-lock"
                allowfullscreen="true"
                webkitallowfullscreen="true"
                mozallowfullscreen="true"
              ></iframe>
            </div>
          </div>

          <!-- Описание и детали игры -->
          <div class="huevo-player-details">
            <div class="huevo-player-block">
              <h3 class="huevo-player-block-title">Описание игры</h3>
              <p class="huevo-player-desc">${escapeHtml(game.description)}</p>
            </div>

            <div class="huevo-player-block">
              <h3 class="huevo-player-block-title">Управление</h3>
              <p class="huevo-player-controls">${escapeHtml(game.controls)}</p>
            </div>

            ${
              game.tags && game.tags.length > 0
                ? `
              <div class="huevo-player-block">
                <h3 class="huevo-player-block-title">Теги</h3>
                <div class="huevo-player-tags">
                  ${game.tags.map((t) => `<span class="huevo-tag">${escapeHtml(t)}</span>`).join('')}
                </div>
              </div>
            `
                : ''
            }

            ${
              related.length > 0
                ? `
              <div class="huevo-player-block">
                <h3 class="huevo-player-block-title">Другие игры в жанре «${escapeHtml(game.genre)}»</h3>
                <div class="huevo-related-grid">
                  ${related
                    .map(
                      (rel) => `
                    <div class="huevo-related-card" data-rel-id="${escapeHtml(rel.id)}">
                      <img src="${escapeHtml(rel.thumbnail)}" alt="${escapeHtml(rel.title)}" onerror="this.src='icons/icon48.png'">
                      <div class="huevo-related-title">${escapeHtml(rel.title)}</div>
                      <div class="huevo-related-rating">${rel.rating} ★</div>
                    </div>
                  `
                    )
                    .join('')}
                </div>
              </div>
            `
                : ''
            }
          </div>
        </div>
      `;

      this.bindEvents();
    }

    bindEvents() {
      // Кнопка возврата в каталог
      const backLink = this.container.querySelector('#huevo-games-back-link');
      if (backLink) {
        backLink.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          this.onNavigate('catalog');
        });
      }

      // Кнопка Избранного
      const favBtn = this.container.querySelector('#huevo-player-fav-btn');
      if (favBtn && this.currentGame) {
        favBtn.addEventListener('click', async (e) => {
          e.preventDefault();
          e.stopPropagation();
          const isFav = await gameAPI.toggleFavorite(this.currentGame.id);
          if (isFav) {
            favBtn.classList.add('active');
            favBtn.textContent = '♥ В моих играх';
          } else {
            favBtn.classList.remove('active');
            favBtn.textContent = '♡ В мои игры';
          }
        });
      }

      // Iframe loader & Stage elements
      const iframe = this.container.querySelector('#huevo-game-iframe');
      const loader = this.container.querySelector('#huevo-iframe-loader');
      const stage = this.container.querySelector('#huevo-player-stage');

      const focusGame = () => {
        if (!iframe) return;
        try {
          iframe.focus();
          if (iframe.contentWindow) {
            iframe.contentWindow.focus();
          }
        } catch (err) {
          // ignore cross-origin focus errors
        }
      };

      if (stage) {
        stage.addEventListener('click', focusGame);
        stage.addEventListener('mouseenter', focusGame);
      }

      if (iframe) {
        iframe.addEventListener('load', () => {
          if (loader) loader.style.display = 'none';
          setTimeout(focusGame, 100);
          setTimeout(focusGame, 600);
        });
        setTimeout(() => {
          if (loader) loader.style.display = 'none';
        }, 3500);
      }

      // Полноэкранный режим
      const fsBtn = this.container.querySelector('#huevo-player-fs-btn');
      if (fsBtn && iframe && stage) {
        fsBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          fsBtn.blur(); // Снимаем фокус с кнопки, чтобы клавиши не залипали на ней!

          const isFs = !!(
            document.fullscreenElement ||
            document.webkitFullscreenElement ||
            document.mozFullScreenElement ||
            document.msFullscreenElement
          );

          if (!isFs) {
            // Пробуем развернуть сам iframe для 100% честного разрешения монитора
            const reqIframeFs = iframe.requestFullscreen ||
              iframe.webkitRequestFullscreen ||
              iframe.mozRequestFullScreen ||
              iframe.msRequestFullscreen;

            const reqStageFs = stage.requestFullscreen ||
              stage.webkitRequestFullscreen ||
              stage.mozRequestFullScreen ||
              stage.msRequestFullscreen;

            if (reqIframeFs) {
              try {
                const res = reqIframeFs.call(iframe);
                if (res && res.catch) {
                  res.catch(() => {
                    if (reqStageFs) reqStageFs.call(stage);
                  });
                }
              } catch (err) {
                if (reqStageFs) reqStageFs.call(stage);
              }
            } else if (reqStageFs) {
              reqStageFs.call(stage);
            }

            setTimeout(focusGame, 150);
            setTimeout(focusGame, 500);
          } else {
            if (document.exitFullscreen) {
              document.exitFullscreen();
            } else if (document.webkitExitFullscreen) {
              document.webkitExitFullscreen();
            } else if (document.mozCancelFullScreen) {
              document.mozCancelFullScreen();
            } else if (document.msExitFullscreen) {
              document.msExitFullscreen();
            }
            setTimeout(focusGame, 150);
          }
        });

        document.addEventListener('fullscreenchange', () => {
          setTimeout(focusGame, 100);
        });
      }

      // Перезагрузка игры
      const reloadBtn = this.container.querySelector('#huevo-player-reload-btn');
      if (reloadBtn && iframe) {
        reloadBtn.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (loader) loader.style.display = 'flex';
          iframe.src = iframe.src;
        });
      }

      // Клики по похожим играм
      const relatedGrid = this.container.querySelector('.huevo-related-grid');
      if (relatedGrid) {
        relatedGrid.addEventListener('click', (e) => {
          const card = e.target.closest('.huevo-related-card');
          if (!card) return;
          e.preventDefault();
          e.stopPropagation();
          const relId = card.getAttribute('data-rel-id');
          if (relId) {
            this.onNavigate('game', relId);
          }
        });
      }
    }
  }

  return {
    GamePlayerView
  };
});
