/**
 * huEVO Games - UI Components
 * Компоненты интерфейса в классическом стиле ВКонтакте 2008-2012 годов
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.HuevoComponents = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  /**
   * Карточка игры в стиле приложений старого VK
   */
  function renderGameCard(game, isFav = false) {
    const stars = game.getStarsString();
    const players = game.getFormattedPlayers();
    const favClass = isFav ? 'huevo-games-fav-btn active' : 'huevo-games-fav-btn';
    const favTitle = isFav ? 'Удалить из моих игр' : 'Добавить в мои игры';
    const favIcon = isFav ? '♥' : '♡';

    return `
      <div class="huevo-games-card" data-game-id="${escapeHtml(game.id)}">
        <div class="huevo-games-thumb-wrap">
          <img class="huevo-games-thumb" src="${escapeHtml(game.thumbnail)}" alt="${escapeHtml(game.title)}" loading="lazy" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\\'http://www.w3.org/2000/svg\\' width=\\'120\\' height=\\'90\\' fill=\\'%23ccc\\'><rect width=\\'100%\\' height=\\'100%\\'/><text x=\\'50%\\' y=\\'50%\\' dominant-baseline=\\'middle\\' text-anchor=\\'middle\\' fill=\\'%23666\\' font-size=\\'12\\'>huEVO</text></svg>'">
          ${game.isNew ? '<span class="huevo-games-badge-new">NEW</span>' : ''}
          ${game.isFeatured ? '<span class="huevo-games-badge-hot">ХИТ</span>' : ''}
        </div>
        <div class="huevo-games-info">
          <div class="huevo-games-card-top">
            <a href="#/game/${escapeHtml(game.id)}" class="huevo-games-title" title="${escapeHtml(game.title)}">${escapeHtml(game.title)}</a>
            <button type="button" class="${favClass}" data-fav-id="${escapeHtml(game.id)}" title="${favTitle}">${favIcon}</button>
          </div>
          <div class="huevo-games-meta">
            <span class="huevo-games-genre">${escapeHtml(game.genre)}</span>
            <span class="huevo-games-source-badge">${escapeHtml(game.source)}</span>
          </div>
          <div class="huevo-games-stats">
            <span class="huevo-games-rating" title="Рейтинг: ${game.rating} из 5">${stars} <b class="huevo-games-rating-num">${game.rating}</b></span>
            <span class="huevo-games-players">${players}</span>
          </div>
          <div class="huevo-games-actions">
            <a href="#/game/${escapeHtml(game.id)}" class="huevo-games-btn huevo-games-btn-primary" data-play-id="${escapeHtml(game.id)}">Играть</a>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Верхние вкладки навигации (Каталог, Мои игры, Популярные, Новинки)
   */
  function renderHeaderTabs(activeTab = 'catalog', favCount = 0) {
    const tabs = [
      { id: 'catalog', label: 'Каталог игр', hash: '#/games' },
      { id: 'favorites', label: `Мои игры${favCount > 0 ? ` (${favCount})` : ''}`, hash: '#/games?tab=favorites' },
      { id: 'popular', label: 'Популярные', hash: '#/games?tab=popular' },
      { id: 'new', label: 'Новинки', hash: '#/games?tab=new' }
    ];

    return `
      <div class="huevo-games-tabs-wrap">
        <ul class="huevo-games-tabs">
          ${tabs
            .map(
              (t) => `
            <li class="${activeTab === t.id ? 'active' : ''}">
              <a href="${t.hash}" data-tab-id="${t.id}">${escapeHtml(t.label)}</a>
            </li>
          `
            )
            .join('')}
        </ul>
      </div>
    `;
  }

  /**
   * Панель фильтрации: поисковая строка, выбор жанра, выбор источника, сортировка
   */
  function renderFilterBar(categories = [], sources = [], currentFilters = {}) {
    const { category = 'Все игры', source = 'all', query = '', sort = 'popular' } = currentFilters;

    return `
      <div class="huevo-games-filter-bar">
        <div class="huevo-games-search-row">
          <div class="huevo-games-search-box">
            <span class="huevo-games-search-icon">🔍</span>
            <input type="text" id="huevo-games-search-input" placeholder="Поиск игр по названию, жанру или тегам..." value="${escapeHtml(query)}" autocomplete="off">
            ${query ? '<button type="button" id="huevo-games-search-clear" title="Очистить поиск">×</button>' : ''}
          </div>
          <div class="huevo-games-sort-box">
            <label for="huevo-games-sort-select">Сортировка:</label>
            <select id="huevo-games-sort-select" class="huevo-games-select">
              <option value="popular" ${sort === 'popular' ? 'selected' : ''}>По популярности</option>
              <option value="rating" ${sort === 'rating' ? 'selected' : ''}>По рейтингу</option>
              <option value="new" ${sort === 'new' ? 'selected' : ''}>Сначала новые</option>
              <option value="title" ${sort === 'title' ? 'selected' : ''}>По названию (А-Я)</option>
            </select>
          </div>
        </div>

        <div class="huevo-games-genres-row">
          <div class="huevo-games-genres-list" id="huevo-games-genres-list">
            ${categories
              .map(
                (cat) => `
              <button type="button" class="huevo-games-genre-pill ${category === cat ? 'active' : ''}" data-category="${escapeHtml(cat)}">
                ${escapeHtml(cat)}
              </button>
            `
              )
              .join('')}
          </div>
          <div class="huevo-games-source-filter">
            <select id="huevo-games-source-select" class="huevo-games-select">
              <option value="all" ${source === 'all' ? 'selected' : ''}>Все источники</option>
              ${sources
                .map(
                  (s) => `
                <option value="${escapeHtml(s)}" ${source === s ? 'selected' : ''}>${escapeHtml(s)}</option>
              `
                )
                .join('')}
            </select>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Заглушка, если ничего не найдено
   */
  function renderEmptyState(query, category) {
    return `
      <div class="huevo-games-empty">
        <div class="huevo-games-empty-icon">🎮</div>
        <div class="huevo-games-empty-title">Игры не найдены</div>
        <div class="huevo-games-empty-desc">
          ${query ? `По запросу «<b>${escapeHtml(query)}</b>» ничего не нашлось.` : 'В данной категории пока нет доступных игр.'}
        </div>
        <button type="button" class="huevo-games-btn huevo-games-btn-primary" id="huevo-games-reset-filters">Сбросить фильтры</button>
      </div>
    `;
  }

  /**
   * Скелетон / спиннер загрузки
   */
  function renderLoader() {
    return `
      <div class="huevo-games-loader">
        <div class="huevo-games-spinner"></div>
        <div class="huevo-games-loader-text">Загрузка каталога игр...</div>
      </div>
    `;
  }

  return {
    escapeHtml,
    renderGameCard,
    renderHeaderTabs,
    renderFilterBar,
    renderEmptyState,
    renderLoader
  };
});
