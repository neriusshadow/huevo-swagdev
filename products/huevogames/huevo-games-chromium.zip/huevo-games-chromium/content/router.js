/**
 * huEVO Games - Router
 * Клиентский роутер для стабильного переключения между huEVO и разделом «Игры»
 * без сброса и откатов от внутренних скриптов huEVO
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(
      require('../ui/catalog-view.js'),
      require('../ui/game-player-view.js')
    );
  } else {
    root.HuevoRouter = factory(
      root.HuevoCatalogView,
      root.HuevoGamePlayerView
    );
  }
})(typeof self !== 'undefined' ? self : this, function (CatalogViewModule, PlayerViewModule) {
  'use strict';

  const { CatalogView } = CatalogViewModule;
  const { GamePlayerView } = PlayerViewModule;

  class Router {
    constructor() {
      this.isGamesActive = false;
      this.currentViewMode = 'catalog'; // 'catalog' | 'game'
      this.currentGameId = null;
      this.gamesContainer = null;
      this.catalogView = null;
      this.playerView = null;
      this.domGuardObserver = null;
    }

    init() {
      // Создаем изолированный контейнер для раздела «Игры»
      this.gamesContainer = document.createElement('div');
      this.gamesContainer.id = 'huevo-games-root';
      this.gamesContainer.style.display = 'none';

      this.catalogView = new CatalogView(this.gamesContainer, (route, param) => {
        this.navigate(route, param);
      });

      this.playerView = new GamePlayerView(this.gamesContainer, (route, param) => {
        this.navigate(route, param);
      });

      // Перехватываем клики по остальным пунктам меню huEVO, чтобы корректно выходить из Игр
      document.addEventListener(
        'click',
        (e) => {
          const navLink = e.target.closest('#sidebar-nav td > a');
          if (navLink && navLink.id !== 'huevo-games-nav-link') {
            if (this.isGamesActive) {
              this.unmountGamesSection();
            }
          }
        },
        true
      );

      // Проверяем, был ли переход по прямой ссылке
      const hash = window.location.hash || '';
      if (hash.startsWith('#/games') || hash.startsWith('#/game/')) {
        this.handleRoute();
      }

      window.addEventListener('popstate', () => {
        if (this.isGamesActive && !window.location.hash.includes('game')) {
          this.unmountGamesSection();
        }
      });
    }

    /**
     * Открыть каталог игр
     */
    async openGamesCatalog(tab = 'catalog') {
      this.currentViewMode = 'catalog';
      this.mountGamesSection();
      await this.catalogView.render(tab);
      this.updateNavHighlight(true);
    }

    /**
     * Открыть конкретную игру
     */
    async openGame(gameId) {
      this.currentViewMode = 'game';
      this.currentGameId = gameId;
      this.mountGamesSection();
      await this.playerView.render(gameId);
      this.updateNavHighlight(true);
    }

    /**
     * Навигация внутри игр
     */
    navigate(route, param = null) {
      if (route === 'catalog') {
        this.openGamesCatalog(param || 'catalog');
      } else if (route === 'game' && param) {
        this.openGame(param);
      }
    }

    handleRoute() {
      const hash = window.location.hash || '';
      if (hash.startsWith('#/game/')) {
        const id = hash.replace('#/game/', '').split('?')[0];
        this.openGame(id);
      } else if (hash.startsWith('#/games')) {
        const tab = hash.includes('tab=') ? hash.split('tab=')[1].split('&')[0] : 'catalog';
        this.openGamesCatalog(tab);
      }
    }

    /**
     * Монтирование контейнера игр в #main-content
     */
    mountGamesSection() {
      const mainContent = document.getElementById('main-content');
      if (!mainContent) return;

      this.isGamesActive = true;

      // Скрываем все оригинальные дочерние элементы huEVO в #main-content
      Array.from(mainContent.children).forEach((child) => {
        if (child !== this.gamesContainer) {
          child.style.display = 'none';
          child.setAttribute('data-huevo-games-hidden', 'true');
        }
      });

      if (!mainContent.contains(this.gamesContainer)) {
        mainContent.insertBefore(this.gamesContainer, mainContent.firstChild);
      }
      this.gamesContainer.style.display = 'block';

      // Запускаем защиту DOM: если внутренний таймер или AJAX huEVO добавит новые блоки в #main-content,
      // мы мгновенно скрываем их, не давая сайту откатить страницу!
      this.startDOMGuard(mainContent);

      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    /**
     * Демонтирование раздела игр и возврат оригинальной страницы huEVO
     */
    unmountGamesSection() {
      if (!this.isGamesActive) return;

      this.stopDOMGuard();

      if (this.gamesContainer) {
        this.gamesContainer.style.display = 'none';
      }

      const mainContent = document.getElementById('main-content');
      if (mainContent) {
        Array.from(mainContent.children).forEach((child) => {
          if (child.getAttribute('data-huevo-games-hidden') === 'true') {
            child.style.display = '';
            child.removeAttribute('data-huevo-games-hidden');
          }
        });
      }

      this.isGamesActive = false;
      this.updateNavHighlight(false);
    }

    /**
     * Защитный MutationObserver от фонового обновления ленты huEVO
     */
    startDOMGuard(mainContent) {
      this.stopDOMGuard();
      this.domGuardObserver = new MutationObserver(() => {
        if (!this.isGamesActive) return;

        // Если наш контейнер выпал из DOM из-за innerHTML huEVO
        if (!mainContent.contains(this.gamesContainer)) {
          mainContent.insertBefore(this.gamesContainer, mainContent.firstChild);
          this.gamesContainer.style.display = 'block';
        }

        // Прячем любые новые элементы, которые подгрузил скрипт huEVO
        Array.from(mainContent.children).forEach((child) => {
          if (child !== this.gamesContainer && child.style.display !== 'none') {
            child.style.display = 'none';
            child.setAttribute('data-huevo-games-hidden', 'true');
          }
        });
      });

      this.domGuardObserver.observe(mainContent, {
        childList: true,
        subtree: false
      });
    }

    stopDOMGuard() {
      if (this.domGuardObserver) {
        this.domGuardObserver.disconnect();
        this.domGuardObserver = null;
      }
    }

    updateNavHighlight(isGames) {
      const gamesNavLink = document.getElementById('huevo-games-nav-link');
      if (gamesNavLink) {
        if (isGames) {
          document.querySelectorAll('#sidebar-nav td > a.active').forEach((a) => {
            if (a !== gamesNavLink) {
              a.classList.remove('active');
              a.setAttribute('data-was-active', 'true');
            }
          });
          gamesNavLink.classList.add('active');
        } else {
          gamesNavLink.classList.remove('active');
          document.querySelectorAll('#sidebar-nav td > a[data-was-active="true"]').forEach((a) => {
            a.classList.add('active');
            a.removeAttribute('data-was-active');
          });
        }
      }
    }
  }

  return {
    Router: new Router()
  };
});
