/**
 * huEVO Games - Content Script Entry Point
 * Инициализация расширения на страницах huEVO
 */

(function () {
  'use strict';

  console.log('[huEVO Games] Инициализация расширения «Игры»...');

  function init() {
    const isHuEvo = window.location.hostname.includes('departament.site') || window.location.hostname.includes('localhost');
    if (!isHuEvo) return;

    try {
      // 1. Инициализируем клиентский роутер
      if (window.HuevoRouter && window.HuevoRouter.Router) {
        window.HuevoRouter.Router.init();
      }

      // 2. Встраиваем пункт «Игры» в боковое меню
      if (window.HuevoInjector && window.HuevoInjector.MenuInjector) {
        window.HuevoInjector.MenuInjector.startWatching();
      }

      console.log('[huEVO Games] Расширение успешно подключено к сайту huEVO!');
    } catch (err) {
      console.error('[huEVO Games] Ошибка инициализации:', err);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
