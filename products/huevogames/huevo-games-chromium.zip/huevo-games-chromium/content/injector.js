/**
 * huEVO Games - Navigation Injector
 * Безопасно встраивает пункт «Игры» в навигационное меню сайта huEVO
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.HuevoInjector = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  class MenuInjector {
    constructor() {
      this.injected = false;
      this.observer = null;
    }

    /**
     * Поиск меню huEVO и добавление пункта «Игры»
     */
    inject() {
      if (document.getElementById('huevo-games-nav-link')) {
        return true;
      }

      const sidebarNav = document.getElementById('sidebar-nav');
      if (!sidebarNav) return false;

      const tbody = sidebarNav.querySelector('tbody') || sidebarNav;
      const rows = tbody.querySelectorAll('tr');

      if (rows && rows.length > 0) {
        let targetRow = null;
        for (const tr of rows) {
          const text = tr.textContent.toLowerCase();
          if (text.includes('видео') || text.includes('музыка') || text.includes('звучок')) {
            targetRow = tr;
          }
        }

        if (!targetRow) {
          for (const tr of rows) {
            const text = tr.textContent.toLowerCase();
            if (text.includes('настройки') || text.includes('помощь') || tr.querySelector('hr')) {
              targetRow = tr.previousElementSibling;
              break;
            }
          }
        }

        const gamesRow = document.createElement('tr');
        gamesRow.className = 'huevo-games-nav-tr';
        gamesRow.innerHTML = `
          <td>
            <a href="javascript:void(0)" id="huevo-games-nav-link" class="huevo-games-nav-item">
              <span class="hue-ico huevo-ico-games"></span>
              <span>Игры</span>
            </a>
          </td>
        `;

        if (targetRow && targetRow.nextElementSibling) {
          tbody.insertBefore(gamesRow, targetRow.nextElementSibling);
        } else {
          tbody.appendChild(gamesRow);
        }

        const link = gamesRow.querySelector('#huevo-games-nav-link');
        this.bindNavClick(link);
        this.injected = true;
        return true;
      }

      return false;
    }

    bindNavClick(link) {
      if (!link) return;

      // Перехватываем клик на фазе CAPTURE с полной остановкой всплытия,
      // чтобы скрипты huEVO (PJAX / роутер) не ломали переход и не откатывали страницу назад!
      link.addEventListener(
        'click',
        (e) => {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();

          if (window.HuevoRouter && window.HuevoRouter.Router) {
            window.HuevoRouter.Router.openGamesCatalog();
          }
        },
        true // Фаза перехвата (capture)
      );
    }

    startWatching() {
      this.inject();

      if (typeof MutationObserver !== 'undefined') {
        let throttleTimer = null;
        this.observer = new MutationObserver(() => {
          if (!document.getElementById('huevo-games-nav-link')) {
            if (!throttleTimer) {
              throttleTimer = setTimeout(() => {
                this.inject();
                throttleTimer = null;
              }, 200);
            }
          }
        });

        this.observer.observe(document.body || document.documentElement, {
          childList: true,
          subtree: true
        });
      }
    }
  }

  return {
    MenuInjector: new MenuInjector()
  };
});
