/**
 * fedorEVO - Content Script
 * Превращает huEVO в fedorEVO:
 * - Все иконки меняются на Федор Яйца (фирменную птицу)
 * - Все названия категорий меняются на «Федор Яйца»
 * - ВСЕ аватарки пользователей меняются на аватарку Федора (включая заглушки без аватарок)
 * - ВСЕ никнеймы и имена пользователей меняются на «Федор Яйца»
 * - Логотип huEVO меняется на fedorEVO
 * - Фавиконка вкладки меняется на Федора
 */

(function () {
  'use strict';

  // Встроенная base64 иконка Федора (24x24 прозрачный PNG)
  const FEDOR_ICON_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAQqSURBVEhLvZRtbBRFGMfnbmd2d2b3bnvXF67HXbm+3dFe6bXWDyolRW0QolxEexg0po1JqRA+mMYaTIyFhDQSGlMkKIYQ5aVFy4sGpfJJE7QYECWRaIqJxBi1GlsQoR8s2r+Zvb1CF5qUmPhPnszO7D6//8zsM0PIHJVILEq4x/6TMpmMUhmNLiGl8VrZD4fDT6SDwXO+RCJhJRJLlXnzH3bn3JG6u7u99xYU7B8wBbr8/s9IfNGKnZY5PmzoVyqi0de6/H6syc/fTgDFnTtnWYWhlm+FCnAFR30CPSafgK6g3xR4X2gYFwzNwbwh0g2vO3duikbTBw0d4BSTuoLLnNpxhVP8wpltfEqo0PKCve7Uualg3up+oWKKU1ziFH/c1EoT+SzfvcB1EMN3hFRXh9yI2dXUZDb6/ad+4yogKCAYpgTDP4JN9+XK/nJMDusqQsK4SMrLK9yo22pVnnV8RGg4pqvYqDG0qhSrGEWaUqxWKdapDDs0hnNctY2l2bDOUGQYF8h9aZ+bN0NLQqGOrQZHUlFAPF4Q4pk1VK+CjMowIlfKKfZyDcSydriZN9Taqj+ZZ/1UQgiIEx6P57aRey+NkpRhTG4hp2jmfJKUlZW40bZS0eiyFYyhKBJBb28vhGHcBLphKNu+vj60tLRkxz0enJCVJSjeslcR6HSzbT0YCGxeRwj84TIMDH4IjVvgGkVVzMDi2oCzZVmjwcFBtLe3Z/teBZ8623SeMwQN4z0321ajab29P+LD/XdbWJ+20P9yHF/srsOXe+rwzqYk2lfOn7GKXNQzhquCYYJTjHKKpNBPT0NfXPvIwnd7Hnj245337Bvalrp0flcdRg/chZF99Ti7O4Xh12txorcGn2yvxaZnSm8x0J3ZX3fOx++cIiX0M9MGr770eLJ/6/Kn3uxu3rg+nThzqDGEI8sieO7RErSvWYAtHRV44/mFOPZKLZrq82cY+L0KjjtnZZxTXOMUF3WGmGkOTRtk1cCS9c1V8Zp4566wD98t8OH7uIWDVXmoqfSjOm6irtIHlcnSzZZoDaU4K+8qBy5Ptqyij7gKJRDY7DLIKcI3aPwyqBcTigfXFS8OeBQYdt07e+7xok1VMSZUG5iDy5A/ea3gILFYyk2eViAQ2HLSqQiZLGf4jdAQUSgKvAr6dTnr7A/NwWUrzb7iDPl+/wdu5kw1NIh6wxz5wb4xKcacmX3OVWzQdRueu+xycHknXeMMSwX/k5TES93IWxWLJZKGOXrani3FVcfkKFexh2v42wFLIzn+K2dYaYhJUhx5yI2aXRUV5UHDd7KHa/jZAUmzbVzDj87qpMEA15AyzQukuLjRjZibrGBbpWEMtwk+2Sd0dOgantY1dAp9arFpfk0C+V0kkzHdaXeueLyUFIWbSbDwMVJYuFxuo/uT/13/Agze/J0bayaDAAAAAElFTkSuQmCC';

  // Встроенная base64 аватарка Федора (128x128 высококачественный прозрачный PNG)
  const FEDOR_AVATAR_B64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAADkASURBVHhe7X0HfJXl9f+797o3CQlh7xWy2QlDRKYoFhWtCCoqIGoVtaLWiYq1zmrFrWyQKVpqrfZntdVf+29/WkUEHChLwg4hg5Hv/3Oe570Q3wSJghg05/M5n5tx73vf9znnOfucRxDqoR7qoR7qoR5+WrBgwQIfgBb9ez38TGDu3Lk9CwsLPyksLHx26h13nF5ZWWlH31MPP2EAIHbq3Gm+bphISUlFXk7+6lMHDhz/1vvvtYi+tx5+orBkyZLmzRo3LyJ+EEQBtm2hXbv2Jb8895cPArCi768KAORrrrnmorvuuqueYU5mGDp46GTTtaCIAiRJANFWNi10ye36ybQH7h8VfX8CAEhDhgyZ3bRp07KRI0cufPzxx5tE31MPJwFUVla6HTp02CQKAn7hpuBWtwEa6hJjhFhaGgYPPf3BI9kHRPQGDRpUSJKE9PT07X379r137dq19YzwQ0JlZaU5ZcqUPhdccMGERo0aXT58+BkvjBkz5uX0tPTxeTl5l0+ZMuXymTOf7VhZWZkU/eyR4JyRoyZrto0+moHd8XSs9Txc6djwBQGibiKjS96H995/7ynRzxEUFhY+qioKYxiyJ1q3bbtt+PDhF5GKiL63Ho4D0I4dOXLkooYNG0JRFIgiF9uCrEOwNQTxZDRKb1bZJS97y2mnDZgzceKV5wBQo9epCmvWrPEaNW+6meyAZa4DmBIqXBtvxl0MtnV2/bRGLTHojDOui372D/c+2LJxcnoFfVaWDPZey/ORld3trTvuvrtP9P31cJygb9++N/i+zxa8hWZgjJOEwbqJNFGGIIghUyjwk2No0679qgsvHnfnp5s/bRC9TgKGDjrtaVFWcZllYp9jYY8u44ChothNxlN+DM0lAXrgoUdB3wWVlZXpic+RN9G1W8E/6McM08LdqQ3QWaZ7ENC4WTP8YtQ5Dx9JhdTDMUL//v1nSIqKzoaKjckeymwf/4wFmO7bONu20ETloplQsxx0bJex9eKxl99Zk3h+6He/G5jUoDFaKjI+9QPsMVRssxTs1VWUeRreT7ExUtchGQ465XdZedt99x1igrPGjrtWt0y0kSVsiHlYH/NwpRln3ytZFgp6FXw8dept+d/8xno4Znj66ac7pKQ22qcJMl51TBywZJRaAg5aKvb4BlYGFp5zPJxlWnBFzgyK7aFjRva/J467/Iyq16Jd2rxtx42SIGJx4KLEUbHV1LDDULHDlFBq6tgR+LjdVWEIEho0bfPJI08/Nog+++Tzz7dvmN6EuAp/8hzAkFHhuHgxyUdThaSRiCZNmu4dMWLEVVW/sx6OESiUm5mTu4Z+nOQE2Ota2KuL2GkYKLI17DVkgIjoO/hb3MVk10FzhYtnO0hC3z59Fy1d+tKhndmjoHCxIEq4zdZQ4VjYrSvYYcrYZsnYpSso1SUccBw87wdIlSW06pyx/45p0wbSZzt1ztpChH7WN1Fma9htKICp4J8pAQaZJvtO07bRt2/f+Zs2bWr2jQeph+8Pffv3XUKLW6hZ2ObZ2GUL2GFq2GVI2G7J2Gop2GVKKLMklHs2PgwCXO2acEURgmSgResOFReNv/Q3dK28wp7jBdvGuaaBXZ6JHZaIrY6IXSZdR8VuXUWxrqDSMrAsFkcgCmjUtn3FzOef6NujsOciSRDwkGuh1NWw01SwW9dQYegoCmxMci2uElQNvXv33jjtscc6RZ+lHr4HDBw8cIqsmWgiqVjluSg1BWw3VWy3aPd+E4mAJaF4fs9NwfmGRe4B1MBDTvder90w8YbZsuOiu6Fhi2+h2FSw3ZKw01BQZBnYaarY4gqMqfZZMSz3kxATBDRt3660d2HhFkGQcK9ro8LRGQPw75Wx11BQ5rm4N3CgiRKLOqalp2267ZbbhkWfpx6+I4wePfoML4hXKoKApW4A6CSyiXCku7/JAKQa6H8luoD9hortMQdLiPiaBiKenxRjnkOupuPzwEGxoaNYl7HLoOspbPfvVXUU2TqKLBmwDTweeEz3M2NTUnCP/00G2G4q2GXIKNVFFAc+ng88NAgjjm3btcVVv/rVZdFnqofvACNGjGho2U4J7ao7nTgOWgbbdSQFqjOAgm22jCJHZOKd9PQ+y8DnyR6uJ3+fYgqyhHxNxeeBjT2Gjt0hAxARt9oKdukGY4ItrogdtoC9noMrTXJHRfb5+x0b5d+QAApjOmKavaqGg46MWXEbHsUtBAGNGqdj8vWT65ng+8LDTz+dmtYovYQWc7Tlo9i3UWwQA2g1MADpcbLsNWYk0u/Fuor9uogKz8VtbsCI2J2MSM/EbkPGNptUgIpdhoqtxDw2lwT0N7rmQVXCqiAJTVWVSZEnHasGBuDfu1cTsd0SUeZb+EPMgyXxkHOr1q0wbvz4wuiz1UMtYEtJSVq79u0YA/TUDayPOUzP76hBAmy1dGw3CTVGFDIOiaA7dAdlmoFtcRe9NB0jyNjziYFk7LDkkJgqYwimEphRSAykM0aocA1c5xgQRAULfRvl1dQP3Q9HkiR7dB3lgYYbYxbEMGjVsEn6+gcee6B19Pnq4SgAIC0vO4cxQGNFwQeBw9y/KPGPhDtNGSWahq22hFJHxSw/wAxXQ7GnYgftXNL/oRiPfnaPpqHI0lDsiPi776KFquAdz0YZI3b191fFYlNmwavBls2kjqzI6NQx463Kyko9+oz18C1ADNA9vytjAEsS8ToZYabK9H100WvCnZaIUpVEu4xdFrl8Jja7FnYYMiP+tzEASRKSADtNEZs9G8/4cazxNKaCou+NIn3ugK7jb8k+UhVSHwpcy8XAQQN+F33GevgWIAbomteFMYAgiZgf87GfxQGOTgTCza6MnYaGXbrFPIdig4xDbvgR8ROMVJNbSfEG+vseXWFE32n72EYqpRYSgHCXIaLSUfGAE2f3TpKgQUoabr755oLoc9bDEYAYICM7lzOAKOA5P8A+m4yw2hGBiM5dNdLbOgse7TSl8H9HIjxHiitss0TsMCzsNqVDwZ/o+46ELNdAhqbro5epMiYgmyAvL29l9Dnr4QhARmD79u0ZA1BRx5OuiwrH/IYV/m1Iu5cIvs2mEDK38El6EHF4PIG/70gqZbchYZtpcmPSJGlCbmj190WR3x/3VvYx19CFzlxJCbppYNTIUbdEn7UeaoDnX1mQ1rJxEy4BiAE8A+W2dchNq6tIkoZFGZkdImCH52OAaTMpQEGt9OQUDB52+twX5s9vFH3meqgC3U/rHg9cbw/54EwFuAZKHQrb1l4U/1i4y9Dwta1hhyWg0jDxgpvEClzksJ7AlGQ0bdlq28Bhw6+t72E4Ajz88O8KkpOT91EkTpJEzHNNlDnkBdRtCUC4jcUkVJbBLDFlrA8C5OpUVaRBUA1WpEoJJsMwkJmZ+cFll13WO/r8P3u4YfLkS5JTklkoVhVFvOI5KLckZsVHF7yuIdkX5HGQt7HVVlHuaFjq+AiYBNAgiQJUCk+HZW8NUhpgwIAB9wMwouvws4X8zPxzPdNlYVhXlvCm76HcPDkYgDwVwkNRRVPELl/BK14MXS1eXyhIEkRZh0xZRJIGloGCgsIPH3744TbRtfhZwvDTz7xfoUCKLKKlquHDuMfEKblo0QWv60ju6FZLYpnKIj/AQ34SWmuUNFLY8ymSBFmkQlgRTRqlbxg/fvwR+xZ+NtC1a5d/CjLtFA19VBObYhYLypCBFV3guo5Ub1CiGthmythjSNhvO1gZCzDB1mFQCllUoUkKdJHiBRKSkpJw5plnXh9dk58NDB8+/G7HsSCLFEq1caZlotg3sMsUa0wGnQxI6uBrh1LPIop1EWWGihLfxczAR0tdZvaAqBgQwl6ElJQUnHXWWS9E1+YnDVSKPWzYsLmObXM9KaqIywpeCCwU2w62syggj+addGiRUUhZR2JgjWUvSzQDsGR8FHMwyHIhkARgxiHPJFq2hYKCgp8PE5xy6oB5lsVr7GhHDDRMvOknodxWsM1wscM0WJCFB1t4SDhR1cOie0w6JFxFvtBRicECNFUw+j9eJFJThFBl9QYsv8CQ1xLQ+w7fD6moI0sobr9QzQLVM/LP0D0f0FVs9X1c6zislI1JA9YHIcAyDHTr1uOnzQTU4XP6mSPmma7DH1pSMNX3sM13UWabVRI3FJLVscvQw110mMDM8ibCEQOYRBwiElng9HtVycH/n3glgtK1EiFiFvZl8X/OaFQ5XLV2gH+Wf4a+n9Uh0PtsEdss+o4jMwB7hio/U6ZyByWdNA0lVKUUeHjIc+Cx+kIVSughmKaNQYMGzSAJGV27nwQMGDTkbi8l4AUUsoY5vo9SPwz7HtppiR1PxNcZsYhIe3SRIcX5aVexHcxi+SRyiZC001Rss1Xssqh4VGG4hwo4DBl7qSyccgX0WQrhstSxhN2021n2UWNie4/Gawj49XgZGfn4xJC7dRO7dZ39n9sptUtYEWPx9xLTUJTTwH7XwAuuB0fiEkAO6wyDIMDo0aN/H127kx5GjBhxOek6ZvgoOhYmedjPUrm0SER8nr7lopUjE/WsLFxFsaminCqCKQPnaNjrmdjrWayBZGegYadvYLtnYZvrYL1t4XPbxJeuha88G+s9B+tcC585Bta5JjbR+xwbu10bJa6BYl/HnsBAia+jzNFYWHefaaCcqoE1GaWaxOoHiejFGkkDFVscLjmqEbsGZKqGGYhcfe3RyC7QUerreCbmwZVlpgokZgwL8DyPmGBMdA1PWhg1alR+enp6GB9XMNvzcMBRsNU0+a4PxTov4FBRbGkoc2QctBXst0x87bn4IO7jrVgci10PTwQW7vF03OJomGSbuMC2cKZtoY+lI1dX0FaR0UKR0EaR0U7X0N7Q0EpT0FSR0EqR0VlT0cUw0d+xMcIxcY5tYLxj4UbbxW9dD886KhbHTLwTt/FF4GKP6+CgaaGU6hBJchgySnSudqLErglrskGKNQvFuoEKT8UzQQBDVkOjkBuGzZo1O3jxxeMzomt50sEbf3+jWeu2rTfSQ0miiHsCD2WewQmuU0GGgN2WgApTQYVtoSjw8F/fwQI/wK2Og5FkHOka2qoaYrICmRbpUHg1bCI9hKRLSa+Su0VuFonXCDKjK9GAenjBDyEjggpJUpCqKMhRFZxu6Jji+FgQ87HGt7DXtbHPcljpGKkR0vfc2OSintkoVLYepqIT1UhcEpBaIZtDYLmEYs3AfkfDI74DPfx+Wie6l+zMzC+KiooaRtf0pAGKeRcU9HpNJv9XEHCp46LEs7CLWcXUcKGizHbwVdzFXwIHd9oeBpoW0hUFclXCMGJzQ4n9zKpvqiJZ0+RaVUXpW5Hy9vxn/n7umvGCDvofw28wiAhZEtFKVVhDyiO2j7/HfBQFDsodGXtIMugqdukmUxNE6CKbmIOnjKtKABYxtHk6mdcvKNgVeLjZoZC4AIkxugRL1zBgyJCF0XU9aeDCSy64Jik5xhbvFEPHhiCOPaaBUk1j7VkfBjHc6iajq2rBD40hip2TZcyJECXqj4RhuRc1nnJG5L/HZRmDNQPTPQtrqZTNdrCXlZlxA5IXqJCKq64WEnYPMQpVOG+3dGyKBxhpORBkGUb4fbHkZJyUIeMXn3yyaZO0tK1E1Gayhr8n2djriNhLxZuug/u8GBrp2mFRTgSXBMiiQIlzJgarEeJHQroXEs+UrmYRPKavlVBKaBAkFZ00DbfGTHyUpGOfa6JC17HNNA61pEUZgGIFpAK3WRrvfzQUVBgyVgcB2tOIG1GFKPLmk/bt2xf94x//OLkKS3r36vUKG72iiHg0HgCWwoo9/xtzMNSkGvxQvIqkb2WGItv59OCEh8Vz3UBiUIlJA0USoJHaofsWyHpPSAYNrWUTN3g+Pog7qPA0lOsJT+ebSH/jHg+pC3I9eWyh0pKxMHBgE5NJEqsn0HUdffr0eTy6xnUWxo4dOySWnMS4d6ShYbdHVrSPPyXF0Z46cMjnlRVoggJRliCzLBkRXIZID00LXY0APy5KgsKITUkctvPlkBkEnuUTmStHfyfJIKCZpuFOz8OGWIB9LBDFXcZEsSt1LFHQiqQAN4bJWORJsDInhmtd6jegDmjqexTQML0hfvvb3/aKrnWdAzL88nt1WUe721c0vOdbgKnir7E0NGH187Rz6MFoYWkRQ6OO/U6in2OUAD82VldJCWOS3zsxNYvvywIU5mXwZE9v08Jf4jGUOdSqRnUOFD/glcyHPYawCZXqCQyN2UmfJHvI0Wm9dL5GsojsjOzXoutd5+CaSRMneT6P9v3asgE3wPtxHx0MmS+SEF3InxhKxADE2AoElXsQTSQJL5D765ooMh3sNKjquaZkF59jwOwB28ALfthvwKSPgMD1MOHSCadF17zOAE3nzMvK+oqJLF3CysBDse9jkGEykalJJEprWLSfEJIEoFiFJFCRCxmMZDvo8CURCwMXMGwUa9SoGiX+4RJ2Ug/7VAm73Rj6W2Qok1vMU8k98vP+L7rudQZuuO3GX3lxPlzpBs8CYh7usXniRxAp709is+6J9+OJvLiFGEBiqoCQDFzaxZ1UBZ/EbBbS3m7VXPBCzatbHZ7bqLA0LA9cOEzFcNsi5tqYNHZc3exEzu/W/SOyhtMUCR/HfKz2XKSxSV8yr4ljhlL1RfspIRmFzMaRq9gzMrm2ZMzJmOi6KHVd1lYWJT65g4e6mkyyGRTs8j2cwWYUqZBFDZIsoGfPnq/XuYzh3Xff0Z+qXmm3X2pbQBDHrywTAnPxdCgkGsnqr3Pu3fFFimDSa8KoZcEsSaEyYOY9uLKCv1L7G0UIwxoHIjjPQBLhEylp7h5W2ApzCxVJZZ4GbbDUxqm477776lZRab9+BS/Iispy/H/zY1gTBGikkf5ToIoKq5EXWUHkT5sBakLS4dzb4QS82DFR7vBBGJTtJCZIFKhEpcJuU8TXgY+ehsVUAFMrioKhQ4c+EKXBjwZ7t21r3DmzYznt/l6aiYM0UIkGLsjkPqmsVYq7dic3AzBbJsTo/74NWQKKqQRuCzTSFHzkByijIFEtmlgpbP6Iwz0rWkdysdu2bbuuzvQX3Hzt9eclJ/HAzy00Zi3JRR+D6zym+xXy/UkPUtAnjPlHsC4GfxJY9T5dlydsqjLC0e6d/s9CySEzKKKImb7DahuIwDVFChNI9QOlpoKPfZcN0EiEzuPxOCZNmlQ3jMG8vIwnRcmAKul40zXwQdxDA3KBSOxTexTFzSX5UNUL4ZAhQ3DNNdfg3HPPhRkOYowu3I+NRDhCuje6z3feeQfr1q3DK6+8gsLCwtrfsySxGkAyBhM7+D5XR7kbFrwcsT4xETnUUOZqGE3Np6ROSRUoCvr16/dIlBYnHGhEa+s2rTaRaOugGtgUszHHp9Fr3BImi5h8WB5LF6BpGubOnYuq8Pbbb7Py6Fov6AnCBLOOHz/+G/dLUFZWRgSo5T2TDy8yBmDrIsq4kQ2kdMJ5BIcro6IMQPWHVGq+z1Yxw3O4UR0Wknbq1OnzH73p9KabbspNTko6SMbNcFPHviQfv6M4NrN6qy4CX8yLLqJR/NXhqaee+oZYrQtI95Kamort27dHb5fBu+++yzqBo5+rhiyIwzcAHyol4ypDx17HZeliSh1zA7A6A/D/aSg1ZHzoB0hXeWCI7i0lJaVi2rRpHaI0OaEwcODAq0xy9wQB15P759m4y/8mAyQIS7hgwYLoOjL4+uuvmV6rawxAu/xIUF5ejlatWh31nmnHcwkY5g0EATfZBspdJ0wVUx9BzQxAjEGFqtR3WOzEcaZBa8sLWByqmBo58pIoTU4o9OrVa2GiKud5zwNsDVP9RPTv8EIm8NVXX42uI4Pi4mI0adLkqIt5IvFoDLB//360a9fuqPdMaV1SgxIziPl173dM7LcNNsmM1QjqNQ+yot1PySMajnnAcnAnVQ2F8QWyT7p16/ZMlCYnDCorK728vLz19ECWJOP1WAywJDzix1nyoqoKSDDAHXfcEV1HBmRgJQYrRBfwu+LxqiSie2nQoAGKioqit8vgo48+Yrn6o90zucNqGBpmYWJRxDOuDYQFIYzQpoItTg0MoBs8b2BJbHra4iSPDZ5IPGOLFi3+cbQTVX4wWLp0qdswveEuWoAmsor3A5ulfl8KfGhkqJAFHYZF2c80p79BA3zw4QffWMjdxbvRs1dPtpAUQ2eJjzBNzGoEwhwCLSALKh0yKqtKl5rcSxEiuaAsd09FJtWJ822Y8ADGjh37jfslqKiowMCBA/k9H8UN5MawBoUliAR4sozXkmLYr/NeBiI0SYGaJAAfZEV9Cwr2WDI+CGw0JQ8rfMZGjRptX7VqlRulzQmBadOmdY/FYuW00Dmazjp7D+ga3gssJIWz81hsnBVyJip1BaSmpeLW22/F8leW47HHHkd2Zi7fRZTwoEWXJebqMLEpaBBZbp3/vVoVryDCsQy0aeqiX24cl57RCpNHZ6N/14ZhTl6DJqlsB0YJczSs6gYOGzYMy5cvx3vvvYeFCxdSL98h4h+NAVgQjIXBqeJJQEdNw2cxnzWsRAkeRTbjOCwrI5dwk++gCxmC4fOnpqYeeOihh/pGaXNC4MILLxyRHLpvgywbJY7JxqZ95bvI1XhhJ+XGeY0fL2pQQjEfRd47L7Lz/+REeXeE2KaqokWqg76d0zBucGNMu7wdZt+ahzd+X4APZubji0W52Lg0H9sXF2LD4l544pZMNIpzg5RcsChhjoZEWFJLCSaIYoL4R2MAYj4WA5FoU2i4yDaw16WeiNowAB+Ry+0EFbt9B+eE1cOE1ERSUFBwapQ2JwQGDx58tcKGLAu4zHWw3zJYxctex8Z46gKih1ZFFg1kzZAsKESEoNIq+lyCwNUXODB1dGrmY1iPNEw+vwV+f0MGXnkgG/9+oRfWLuyL9csKsHFZF3y5OAefz8/B5zPz8dmMfHwxrwvWLsrC2vmZ2Lq0G954uDdap4VMUANxvgtWvb/o/74NFZJ8KmcASTSwwKdcwNGJT0g7n1QAeQFsYLVHc41DI5vOUtI0nHbaaZdGaXNC4MILL5wnhTt6qutiH5uyLbDWrfmuxxsdVF48yQyg0BeO7mxDU9E63cXQHo0xZUxLPHtLR7zxaBf8d2ZvrFvUB5uXFmDTom74YkE+1szLxarZ2Vg5Owcfzc7Bytl5+GRWHjYs7IlP5xfir49nY9HDmXj3ue74amYvbFqejRnTusEK+/GjxDkxSNE7LtWyDANfUht8DVG/mjFsTmVzEHXs9RTcZ3O3m1BVVYwaNeq5KG1OCHTv2W2GqFKiQ8RTnsNSlzS4eb8m4Gs/DT11mpsXJbiIwDHRpV0MYwY3xn2TOuNP9+fhvy/2xpeL+mLz0p7YtDAP6+bnYe2cLKyenYlVs7Lw8awcrJqZjU9mJTALn8zKxNoZmfh0YXdMv7kzCrLjCByZpU6bJ3mYc3cmPl/SAZuXDMKlp5FNwA+F4DYJEaYWQZzjgIIisQFYdDDFb+I+9rk02rbmgpDqGPZKUru8qWGPr+Bph3se9AyaqqF/v37To7Q5IZAUS3mGulgo1r3Qc1kMYI8dwxe2gQVagPZMzAtoHtjon52Gq0a2xZNTOuGN6d3xyfxe2Ly4J4oWdce6BXlYO5cTdhXDnFohvf+LZTl48OrsQ8xVVbI8c3M2vlqSiw0LuuCPD+TDJnVF5VWha8azk9UJdrxRYY0lMpsX9FFygHJDZO3m1YldHROZwkSD6V5HwSJfP1SAqqoacjOzTzwD0OHLuVnd/s7CnIKIq4wYHtNMTNIM/CLdw5C8FFw1qhmevaMH/j29AJ8t7Ib1y7ti46Ku+Hx+NtbM6YRVs7OwclZuNcLWHrOxZkFXzL87E+cPTMcpOek4pXMKzumXhqen5GL13P5YMyMHa2Z3xqqFp6KgM42j44UpzDWrgVg/BFL5O1X3PsiaYikFrLG+wCixa8IEA/DGWZn1UK7wTRhh8E2WFYoFnHgG+MPsL2Ods7pupwWNxQ0My0zGtWe3xqO/ycZfn8nFqiU9ULSkOzYsysba+Z2wck4WPpmRj09m5jFx/vHsLHw8O5uL9mPAtS/kYt28XKxfnoPPFufii/mFWL+4H75ckoW1M3KxZkY+Pp6dgS+X9cXFw1owBqAaf0pRVy/1/mGQdv+ploG9Dm+L22ba7MibKLGPhInmU2KCA7qMNzwbLmuh432E6enpPzwD0GmdfYZNap+d3ev8YQNOWTBqSO6XV4xoeeC5G/Pw7h/64tMFffDlsu74akkXrJ2bg1WzM/HpjExO6Fk5WDkrH5++0AVrX8zDmhl57PXTF3Px6YvVifrdMA+rZnbDJzO7MHvhkzkZWD0jF6tnZuKTmfn4mCTMnHbYuKwrrj6bh21ZrEFJlKhVJ9hxQ+Y+iminqPh3Eo3Bl7BTt/nEk+/AAAwpSGQpqDBlvMkYgAfLiAEapzf+YRjgmts+ig8aMPb0vt3y7r/wjB4rJ43Kq/jDr7vhL4/k44O53bHu5W6M4OvmZeLDeRn4cHYuPpmZi1Uz6TWHLf5Hs/MZwT+ak40P53RmBt3qmVlYyXZ/Hj6c3YUTqSaka1V9rYJ0fUbkWXTNzuz3VTO7YuXsXKwMGe6jWV3YK71/48vdceUvDjOASNVKwnePDh4NKd2r0thblgNQYcsSXgri2Gdza55G1VCKt6Z+wZrwcKyApp8oKLVlrPAsGAkJoCho1aLV8WEAAMq1Ex8uOHvYqGuGD+iz9IoLCosenNwTL93XHf95vhvWv9QFGxfl4/MF2aF1nomPZ2VxopKuncGJwgy5mV2wamb+IaTdyF+zsXJOZ6yck4HPX8xkxP34kPF3FJxNkiUXn8yi69ArMUAW8w74//m9MIaY3Ykxx+pZWVgzMwdfvlyAET0bcVeQ+eO0g46/F0C1j7zwhU4xU3B34LH6v9oEfWpC6ibiKWE6Mk9GhS1hCWsb411JiqogNzf3+zPAddf9ttXAYeeNG1pYOPP80/I/uumSrnjutny8+VQuVs/PY1b0F4uysHouiXISqYRcd388m+OaWWRo5WDlXP7zajLu5mVgNYnjOZ0ZrpnbGavnZWL1vBx8Nicfa+bns2DNZy91xhcL8piPn8B1hOQKMqSfOX61KBsbFudjw5Ke2LCkgOH6pT2wYWk3bFzWDZsJl3LctKQ7Ni7pgQ1LemDbqwX4nycK0NAjt5RP7eQNKsefAUiy8LyHhkmujTLPRIn+/YhPyKaMsaQQGY38RPQFPh81R8xMcYChQ4c+HaXrUWH0eef1GN6v61+uOb8AT0wpwJ8f6oVVcwvx5bIcFP0xD9tfLsSGl/pg/ZI+2LCsEOtfLmDRt/VL+2DD0n7YsKQvPp/fC5/N64lP5/XBh3ML8c953fCv+X3xn9mn4P9mF+Lfs3rhXzN64H9f6Ib3nuuKt5/Lx9tPZeGdP3TBK890wztPdMObj+dhxcN5+NNDhPn44wN5WH5/Dpbdl4dF9+Rg4d057JVw7l25ePLGTnhgUltMm9AO905oj7sv7Yjbx3bCjRdk4LoLMnHt6CxMPCcDFw5piXNOaYyz+zXGqP5N0akxBU/I+OMeAKvZP85dSsyoFPjpY+McA9v9ALtNDVvs6mNiao98xBwxADFDpWHgmeCbDHDBBRd893OK7rj1xrN/ffW5j7/09BVvvPfyNR/8z/yx76947sL3/zb3uvdfe+aSOcseHDD19Vnjpr85d/yDb825eOrf54yb+vaMsVP/OmPc1NfnjJ/613kTp069fsg7PbOS0aVDA4zrmIbluUn4a14KXstJxZudUrCiY0O82j4Ny9umYlnLZCxqnoS5TWN4smkKzklx0NDRkGIbcHQFti7D1mSYigxDpmAOJYIk1o3LOnJryA0cDSkH4RsqGsdtJPkGyyCynAQbyMR/jhLxWJATRcRY18HXcRPlWuIsoyhRa4980ASfoEbTxg5aNu73whmLiVH0HTuyU9BPOAw6Y+wQjZ26KWC06aHcsHFQELBHElAqCyiTBOxTBBxQRRzURECTAENFpW3j/Vg6OlPPYA0BnJpRgqXKSPNVNG9gIbNlgN65DTCsIB1jhrXBdedn4N5LO+KJa7Mx7448vPpANv76WBf87zM98eWSAbjlks7sOlSRy40/YoLaMwCbDhJ2AbORNGEkkfcC8vw8Xf9Kx0aJZ2M3q/blE8RrPU6uBuRdxJQP4JVD5a6FyaTKwnVJbZCKa6+66sc5w3jF6yv6NmrSuJJu5HTdxLZ4gL2Ghs2mgQ8dDX83TCxXdbygW/idYmGKoGKCIGOsIGO4oqONZsAyNDRKMtChWRLy2jXAwG6pGD2oKS47oxkmn98a90zsgKduzsLce/Lxp4d64u/Te+E/z/XE6rk98cXCbli3pCu+WtYd65f1YK9f0e8L8/HZS93x6YIu+HJWB2x9tRCjB3EDkDBK3KMhifZEjQKvcqZrUPZShaTwjh8yKq8OHGyP2ax+L0rI74uJ84+KLBV7NQU7PBNDzTAUTHWBDVKK586d2zZKm+MKlZWVJlX/vvbaa/bZY8ak3fXAA4NGjrpkUI8eQ0YLgryXdqcpCDjVNnC6ZeMUz8EpDQyc0sLEgE4+Tu+RjLMHpuOic9riigszcOfVGXjm9k5YdG97vP77znjn2a5YOas31s3ugw3ze2P94j7cuHu5BzaSwUdRxAVd8NlLOVgzPwdr5uZizew8rCZvIHQLEwElel07Ixv/nZOP9+d1wtYlmfjjg/0Rc8LZBDUQuDZIRCYXjw6GYuldQWHuHl1Tl0Tc7rvYHZgoCaeGRQn5fTHRLcQmopoqNrgucqoUhHTo0KHouB5W+fzzzxt33XXXoD59+ozv17ff4jat2/ylT6/uxacUdNl5Wt+8nad2b1/2y2GFuGRED1z9yxxcdV4b3DkpC9NvzsWzU/Mw59FC/PnZ0/DP2adg5ZK++OLVU7H5tVOx/c+nYNfr/Rhuf6MPtrzeC1//uRe2/LEXti7vjo3L87HulRysW56Lr5Z2wcYlXbF5MYWOu2DTovB1YRdsXtgVmxZ2xcaFXbFhUXdsXNgDGxd2x4aXumHDS12xfkEevpyXh/Uv5WDzK92x4rG+yGjGB1V931IxnjjixGdjXRNt36KAVFnH00EMu+MayjWa+JEY/nB8MDFHkVrKdzka3vUCJLEYAK9XyMvLe4vc9ygdvzesXLmy2Q033DCrXbt2y33Pf9Ux7Fc6tG7xj7OHD9x54aihOydfPnL7LVees/nOX43cfNfVwzZfM7rLgYuGNcX4wU0wflBjTBjYCBMHNcTEIY1x5eBWuHJoC0wa3hxXnNEEVwxvhGvObIpfj2qNKRe0w69Ht8d1ozvg+jHtcculbXH7+La4e0J7PDCxE+6f2B6/u6IdHv1VOzx+XXtMv749nvx1Bp66MRNP35SBp24m1dAez07pgBdu6oQZv8nA7DuysPi+Lnj1sV5Ydl833PCLDohRi1otyra+DRONnmzHk5tHuX1BQIam4a0gwD6y+NnUj9pm+GqPtPPZPGNTY0MjuAfAy+0URUaPHj1uj9LwBwFSAYSbKyvtGe9vtmfM2GxfMPk1e/Cpv7iJuT6CgCxBwyLFx2JBwlxRwDxJwHxJwjxJwVxJx1xZxyxJxQxBxXOihkdFDXeJCm6mYlFJwS2Khd7haJWjI7e4q/6Nzh2kiiNXM6CF5Wfs74z4tQv7cn1flfChe0cLTtcLu5vONC18FCThIIV3LQF7VBp2Tcba8dP/hGzINZtZrDHjeRIdUBmuUSwWw7hx486I0uqEwvTp01slN0ipoBuiYoeiuMUs/TJLwT5Txj6TXglVhlTZyn62qPWZOl407KcjXz0LFa6KIs/HBHYMPO00Kubk7iBVGfOmCsKEW1jVPYx6ElVFPp/nEyV2TUjWPhv6RARnxh0fECnS1C5Bgi4KuNZzsCFOZxsRkQ5PB40S73ghHWZZqovY7LvoalCcgT9j06ZNS15//fWWUZqcUKBBBc1btfkn3ZQqiVhGkzPZ+JPaxbr57H1e/rzNFrBPF7DP9vGI48EXqQuGdC7V9CWqg6sT7XgiixFQ0Qi5d5RvJ2YisS8ISFMMPBnEUeZrbHj1tlo/4/fHRKUwJYH+5gcst8DnEwrIyMh4K0qPHwV+cfrIh1V2OJKAia6DCscIT8yo/kBRZCPZHSG0cjVsdUTssEWUezZe9gK0VSimTjpcC+cHfn9LvjZI0kYPizhFhbt3tOAFuo5/xAIctCzsoZGwLJt3fMV9TchnEIs4YDuY6sTCphAJhmngvPPOuydKix8FHr377l4N06irR0QbTcXaWIBS1up0dKTdv9sQ8bVLFrQent2rM71KjPR2Shx99DBgdAKKOHghKy9cZTF9VcQVlo/PY3GUWjTQUcDXDhl8NPC6dkx+LEhrsscU2bzBQu1wBLBhenrlgw8+mBulxY8C5Id2ap+/kpozqBHjad9nuj3xEJyLqz8c+x9N1TZ1bHFEPg2DnRpKJdB0QIOCclvChsDDGDsshWZRuMPFHMw+OKTjv5+K4HmB8PNh+Rbpe+rHJ5FfStPBdQFbTYPV6LNDK35InZ9ACigZJsotBUuTbJhUgh6qo7zcvI+Pq/t3rHBK98JfGTqNMZExiOreHQ+72cRsOvqFikUpmkVHrVZ/YH4GEO+FpzYorvd4zxwtdpkhodh3cT+dsMGKULlxxkbMihoUIphCRpvCRrjWVlIkjERy72TWlEIDGIj4Mk7VTbwXJKPMpaPlhXB2Dy/Q5Mx8/MV/4tlJffLTUzgSA06kSmAWfZSgGxYuOP+CunU6+auL57Zt3ro5405PEvGaF8M+dhYP6Xlyj/gDRh+6tkhdNAdtHSsCH/kquZ0GE9Eaq4oRIGh8fi9Z8MQMUWLXhLz9jM8xogohunddVHC952Orm4YKOibGFJhdUhPj/lBIdhGdM0RYbAv4IIihRTiClu6xZctW+5cvX173hkcXFvZYJocRsnNJVFL9O5uDo2GLo6K4htFo3wWLyDi0dazzfYx2NSYJKB5vshFqVH5NqoFcxtr5/KTnWSInHAffUVUxM8lHqedivyKhyBZYQQYf4lD9fo43cnWooMiRWMlYsS5hv6fhJhoMEY6MpeBP/9NOnRtd+zoBvxp9cX4s8A/QghqSiBV+CvY6JguOlKoaiqm6pYYHry3uNiVsM2zstjWUeRoecvl5OzSJUxEMLglYsUftCj1oND2LN0gSzrccrIrFcDA09OgkEDrUYZNLZVw8yBO9n+OPfIIolYyVqhIqNDpKN8YOqWASTxTQICm2/7bJU+ruUTI9evR4J2GpDrQcbAs8bHcEdmQaPeSxMAARgUar0YFNezUN+xwHi2IeWoWNp0RQnvOnTpzqBD8cGAoJT921ioLpnotSCkSx3X5YXe2h7FsY6NnxAxp9CSS9z9dHQomqYHfMx01eeIoIM3AVnNqv8M3omtcpuH7KlP6pqXxgJBktT3s29tNhSwafiX8kb6A2yGfsHx6pRkZjuWPiL7E42uhcj5NBaFMvPmtDOzybiAYzsGZP1qLNAylDDQP/kxzDfttGiSGwg5/J0Ks6t4/X8h1/g68m5LV//Bi8vZaEfyV5aEhd1uFktXg86cC1116ZE13zOgXkmnTt2nWFxDphZXRQVazx4ii2FWwm3XacF5OYotJS8R8vhg50Ji/F/MkLCEfT8cCRDFXgLeIk7lNlE484LoqSLJRYFsoVPqGbTvo8FgY9VqQu4D10hpApYVfMxWVm6PqyxI9C00DmRNe7TsKdd96Zk5rakOUHaLeNc2zs83RmENY+RFxbpBCyCJg63ghS0UjjkTsyDCl9y+v/uWtHCznA1PG/gclsCBrYvFflop7GtNM0rhNl8NWMJCWp7EvGS0EAjULhYWt606ZNS2fOnNkxutZ1Fgb37DmNBjcQAahLeLZvAgbNyo8+9LEh6c2NjstUDGwZr8UDtFT4OT6KZEChRZQFJEkifuO5KPJdQJPDwUt8NDvt/KJQTdU2hP1DIDEyHS37ecxBNqm0sAzNttmRsrdG17hOQ+WGDUkdOnb8ghuEChrLOt5OClDBhiIdPzXAjn/VQ+KZIvZZBt4KUrhNwAxCiheIuC/wAc9DsUHRPH48LJvMxY6w4926tPu+c8fOcUQycIsDF5eHAyASgzVzc3NXA/Cja1znYdL48YNTG5BBSGJMRg+d5wloUjZ7aMPE9mNMqpDhREYTuZqMsDqVTuv4WyyJu0/hfN7xpoMK10GxJWCTY2CjSwWbdIQLH8LAK2/49aLf8UMglXlvdqjSV0SJLmKbKeGAbeLZwIYeGrDk9jVu1Bi/+c1v+kTX9qSBwsLCh6l2PVEyPdiw8FksjjJTQKmqYKdO1TTVF+hYkFypg5aOFck0WJHPFzIUES8mBThoG+wQ6jKFmO/Y4hLHhHQCOT03SSRbQqmj4K1YgGZsHrDOvBjDNjB8+PC6kfH7vkBt5FlZWe8zPzz0DH5h2tgUo4IKcr3CAQjRBToG3KNr2EXZRFfDK24K4mxSmYS2qon3Y3GUsGALpaCP7/d+F6QjcynhRX0DVFjyqR+gi0auLLWt6awAJrt77tvR9TwpYenSpfkZGRlsnDyNbKPXs20bXyTHUW7S6JPjK3ZJrbDBSmQYmhYet2M82SOKOIt67Hw/PJblx2MAyizuMHR2fMymIMCQcGA2NX3SJJF2ndrtmj5z+sl7bnAUxowZM8h3/VJmFLJpmTKGmQ7WBTE29OB4MgGFcCmPzuoKbJEdXHW9bfOEjyjiSSpa8axjsj2OFSkFXq6LWJ/kYSQZfWxKGg3PEpAcBMUTJkzoF13Dkx5+ed7oiQ0b8GPkuToQ0F/T8J+4j3LbYQct79Uo7MqnY1JShPQ1EYo6Y77LjqWYAxl0FNZltfqBjUHhiaVNVA3/Zoc3kSrg100MbKbjXqPXOlZk921QHISeiTKLGhP7W2IOxtE9qXQcDF+P9CbNcMlll10UXbufDIwcOXJaEPDTL5hhKIpoaehYHvdYBdBugxIidJ4OuXYGSjQdXzs87EsL+H2NtnJTx7sxH0lsyKKEMy0T2wIXewyR1SqQF8G8gFqObvkuuNWicwI5Q+7QTewzNawPfJzlULeyCIMGSNLOT0nGxRdffEd0zX5yMGTIkHt8n/cUsumggsGaHZ5yA5S5HvZYAsuI0cHLO3SbvW52xWNy0SjGvt8x8Kjv8sSQJON+30ElG8JI16WoIDEfb8eOfv5YkGIOrHKYXD3Twj/jAfoY4fTTcOpnWjwJI8866+QK9hwLnHHGGfcmJ/GhTbzpks4NlvFr08d2N87GqWxxBWz2FJTLRBwK0dZeBUSRXD5Wv++bGG9S2bmANFXCv9w49tgGa+HmsYDj7xqyTKglocw3sMx30ZKITlPKwlnHaakp+OW55/58iJ+ACRMm3Nu0SdOQCUga6Kw6Z4Ch419BEmBQ5E5gVj2pg2PpvKGpXNRfX2yLWOfH2HHvFJcYbjnYGnNZ5U+RzesRo589FiTjttjRsTEpwB2eA4dVGVPCihO/YWr6vsnXXF23yrtOJIwdPfbcpk2asYHTlDPgu0JEI1XDk34y9vg29pIlr4tsd5JxV6zp4Zg1igLyWj3avVREykK7NaiK3axXX0eRI2CfK+Nx1+fDq2UZM2KUp6D/G9huV//skZBJCzr1m53xJ2MnMSq5texMQBW7TB0Vno534x5GkJvHInwac/OodqFF6zYlZ51/8U/P2v+ucP/99/du27r1+zT3lksDPgpepdIy28F/vVSUeya220R0stgpikbhZBq8REmUMJ7PFr3mlDMxDhWo0s9lhoB1fgoywl6GvrrKfHFW71/joc41IGtm0Zm3QmNceXOLhZ1skoeEA5aMrwMPv/MDtEp081IxqyDCNHS079D+X7///e97RNfiZwubNm1Kyc/Pf/GQXUCxAuYqKmiqqrjTD/Bl4KHCNVGq8WINvssSRZQqy+iRF0FVPdUIRq6kSelegxEIpo37PI+PWpNkPOP7QKLBsxahadr5dNTrXsoq0kwEl9STjmIaCOW5WOK66EsuHjs8mp6HJ3ZSk1PRu1ePpwEE0TWoB0EQzj///CuaNW9WTAUlrB+QFi5cvAxdZUT7IvBR4agoMQXs0WWUqSorpNhicwLWXL9H6oI3WpBbSVJgVcxBC5YwktBD07HDM7DbpABRTZ+vjlsdmdkVFYqC/WRjxAysCEycaZpQmGvHG0vo3mVJRZsWbXaOG3PRZdFnrocIPPHcE20KCnv80fM9Zg+Qzky0RNGidtY03Od7+DhmY0fMQYVp4YBCYp/r5Jpj/GQnEMFE5vOTGtnn6rje5d02VC72VODhAAshV1chVTERkzioGij1dGyI23gpiOEs04JDUovteOompgMzBKQ3bIjT+vZ/ee7zzzePPms9fAuMm3j5yJycnI+8xAEJrOkjbNmiY2oUFb90DMz0XazzAzZLv9QRUWqK2GNIbHcSwWjePol/Fu0zKf3K++736RreiplwwpNI+tOJ3R71NYZhZNYEwm2LYjq6TVewn9AysNu38HbcwzTHQoGhQ2b3RBY+2RXcw3B8F5m5Oe9PvffesdFnq4daArWdDRo06LIWLVp8RJUxjBESUcSw8JSYIkvT8WvHwat+gNW+x8KsNKzpAJ3OZaos7Fti8q5exhiWzGb27/JUDDKpgkiEo0l413NYK1aJIaHclFDhKGyXb42ZWBvY+IsbYKrHkzdNwzMI2LSOKvMIXMdFq5atPhg+fDgdklh32rdOZqCDkokRMjMzVyaiiIR8Uhc/s4BErypKaKVqONWigI+FBy0P8xwX7wQe1vomvorZKPJt7HIN7HFsVPpx3GIH3M6QZFzn2NiRbOJz38JbMR/TgwDXWBYbzNRKV6CpXPow/R62odFup8OsGqSmICs764NhwwYT4X+ck7x+6kCMMHr06CHdunV7OTU1dTe1SR9mhlBNhOPZmZ/PRqpKiMkKWqsKOusaemkaBisazjJsDDVMNNOos4g+r8CRZOToFjopGhqGw555zoJUD11XCQdV8O/0/RgNa97Zq1fhklvvun3Mj36U688Jpk2b1vi004ZO6NW997+aNWle6VoOH9IcEoe8CDIgqfOXEZCJ6QRRw93LDEsaTEm9BGFYOqFmDmFi15M1LyNwXLRt2+pAp44dX7lk9JjJf1qypEn03urhBMOLL77YdsSIERedfubpy9q1a/ufps2a7vPiASzXZjl2xgxVTi8/jNXHy/Czfrn76XkOUmIxtG7WbF9mVtb/K+jb94mLLrjwwnf//Oc20XuohzoECxcubDZ58uTTBwwYcPmQIUNeyMvPX5HcIHlFRufOW9q3b1/SpHHjkvSG6SWNGjUqady4cUmTJk1K2rVrV5KVlbU5NbXhit69e6/Iz8+fOnLkyMvvvO22Ia+88Uaz6HfUw0kIAGIlJSVpCxYsSHvs+efTng+Rfqe/10fo6qEe6qEe6qEe6qEe6qEe6qEe6qEe6uFkhf8Pcswz9WUvc5gAAAAASUVORK5CYII=';

  // Настройки по умолчанию
  let settings = {
    enabled: true,
    changeCategories: true,
    changeIcons: true,
    changeLogo: true,
    changeFavicon: true,
    changeAvatars: true,
    changeNicknames: true
  };

  // Статистика замен
  let stats = {
    categoriesReplaced: 0,
    iconsReplaced: 0,
    avatarsReplaced: 0,
    nicknamesReplaced: 0
  };

  // Загрузка настроек из storage
  function loadSettings() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['fedor_settings'], (res) => {
        if (res && res.fedor_settings) {
          settings = Object.assign(settings, res.fedor_settings);
        }
        applyFedorEVO();
      });
    } else {
      applyFedorEVO();
    }
  }

  // Слушаем изменения настроек из Popup в реальном времени
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.fedor_settings) {
        settings = Object.assign(settings, changes.fedor_settings.newValue);
        applyFedorEVO();
      }
    });
  }

  // Создание элемента иконки Федора
  function createFedorIcon(extraClass = '') {
    const img = document.createElement('img');
    img.src = FEDOR_ICON_B64;
    img.alt = 'Федор Яйца';
    img.className = ('fedor-icon ' + extraClass).trim();
    img.setAttribute('data-fedor-icon', 'true');
    return img;
  }

  // 1. Замена логотипа в шапке (huEVO -> fedorEVO)
  function transformLogo() {
    if (!settings.enabled || !settings.changeLogo) return;

    const logoSelectors = [
      '#mh-bar .mh-logo',
      'a.mh-logo',
      '#mh-logo',
      'header a[href="/"]',
      'nav a[href="/"]'
    ];

    for (const sel of logoSelectors) {
      const logos = document.querySelectorAll(sel);
      logos.forEach((logo) => {
        if (logo.getAttribute('data-fedor-logo') === 'true') return;
        logo.setAttribute('data-fedor-logo', 'true');
        logo.innerHTML = `
          <span class="fedor-logo-wrap">
            <img class="fedor-icon" src="${FEDOR_ICON_B64}" alt="fedorEVO">
            <span class="fedor-logo-text">fedor<span class="fedor-red">EVO</span></span>
          </span>
        `;
      });
    }
  }

  // 2. Замена фавиконки вкладки
  function transformFavicon() {
    if (!settings.enabled || !settings.changeFavicon) return;

    let link = document.querySelector("link[rel*='icon']");
    if (!link) {
      link = document.createElement('link');
      link.rel = 'shortcut icon';
      document.head.appendChild(link);
    }
    if (link.href !== FEDOR_ICON_B64) {
      link.href = FEDOR_ICON_B64;
    }
  }

  // 3. Замена категорий и иконок в боковом меню
  function transformSidebarCategories() {
    if (!settings.enabled) return;

    const sidebarSelectors = [
      '#sidebar-nav a',
      '.sidebar-nav a',
      '.sidebar a',
      '#sidebar-nav tr td a',
      '.mh-side a',
      'aside nav a'
    ];

    const links = document.querySelectorAll(sidebarSelectors.join(', '));
    links.forEach((link) => {
      const href = link.getAttribute('href') || '';
      if (href.startsWith('http') && !href.includes('huevo.departament.site')) return;

      // 3.1 Замена иконки
      if (settings.changeIcons) {
        let existingFedorIcon = link.querySelector('.fedor-icon');
        if (!existingFedorIcon) {
          const oldIcon = link.querySelector('.hue-ico, svg, i.icon, span[class*="ico"], img:not(.fedor-icon)');
          if (oldIcon) {
            oldIcon.replaceWith(createFedorIcon());
            stats.iconsReplaced++;
          } else {
            link.prepend(createFedorIcon());
            stats.iconsReplaced++;
          }
        }
      }

      // 3.2 Замена текста категории на «Федор Яйца»
      if (settings.changeCategories) {
        if (link.getAttribute('data-fedor-text') !== 'true') {
          const badge = link.querySelector('.badge, [class*="count"], [class*="badge"], .counter');
          const badgeHtml = badge ? `<span class="fedor-badge-preserved">${badge.outerHTML}</span>` : '';

          const textSpan = link.querySelector('span:not(.hue-ico):not(.fedor-icon):not([class*="badge"]):not([class*="count"])');
          if (textSpan) {
            textSpan.textContent = 'Федор Яйца';
          } else {
            const icon = link.querySelector('.fedor-icon');
            link.innerHTML = '';
            if (icon) link.appendChild(icon);
            else if (settings.changeIcons) link.appendChild(createFedorIcon());
            link.appendChild(document.createTextNode(' Федор Яйца'));
            if (badgeHtml) {
              const bWrap = document.createElement('span');
              bWrap.innerHTML = badgeHtml;
              link.appendChild(bWrap);
            }
          }
          link.setAttribute('data-fedor-text', 'true');
          stats.categoriesReplaced++;
        }
      }
    });
  }

  // 4. Замена вкладок в ленте и подкатегорий
  function transformFeedTabs() {
    if (!settings.enabled || !settings.changeCategories) return;

    const tabSelectors = [
      '.nav-tabs a',
      '.feed-tabs a',
      '.tabs a',
      '.mh-tabs a',
      '#feed-tabs a',
      '.wall-tabs a'
    ];

    const tabs = document.querySelectorAll(tabSelectors.join(', '));
    tabs.forEach((tab) => {
      if (tab.getAttribute('data-fedor-tab') === 'true') return;
      tab.setAttribute('data-fedor-tab', 'true');
      tab.textContent = 'Федор Яйца';
      stats.categoriesReplaced++;
    });
  }

  // 5. Замена всех остальных иконок на сайте
  function transformGeneralIcons() {
    if (!settings.enabled || !settings.changeIcons) return;

    const topbarIconSelectors = [
      '#mh-bar .mh-audio',
      '#mh-bar .mh-bell',
      '#mh-bar [class*="audio"] svg',
      '#mh-bar [class*="bell"] svg',
      '#mh-bar [class*="search"] svg',
      '.mh-actions svg',
      '.mh-icon svg'
    ];

    const topIcons = document.querySelectorAll(topbarIconSelectors.join(', '));
    topIcons.forEach((el) => {
      if (el.getAttribute('data-fedor-done') === 'true') return;
      el.setAttribute('data-fedor-done', 'true');
      const icon = createFedorIcon('fedor-topbar-icon');
      el.replaceWith(icon);
      stats.iconsReplaced++;
    });

    const postActions = document.querySelectorAll('.post-action svg, .wall-action svg, .like-btn svg, .comment-btn svg');
    postActions.forEach((svg) => {
      if (svg.getAttribute('data-fedor-done') === 'true') return;
      svg.setAttribute('data-fedor-done', 'true');
      const icon = createFedorIcon('fedor-action-icon');
      svg.replaceWith(icon);
      stats.iconsReplaced++;
    });
  }

  // 6. Замена ВСЕХ аватарок пользователей на птицу Федора
  function transformAvatars() {
    if (!settings.enabled || !settings.changeAvatars) return;

    // 6.1 Все теги IMG (включая специфичные селекторы huEVO)
    const imgAvatarSelectors = [
      // Точные классы huEVO
      'img.hue-av',
      'img.hue-av-main',
      'img.vk-person-av',
      '.vk-ava-box img',
      '.hue-post-card-head img',
      '.pv-c-av img',
      '.vk-design-ava img',
      '.zv-artist img',
      '.zv-crew-people img',
      '.zv-likers-avs img',
      '.zv-who-row img',
      '#hue-fp-modal .hfp-row img',
      '#hue-fwd-modal .hue-fwd-item img',
      '#hue-mention img',
      '#hue-share-modal .hs-row img',
      '#hue-who-pop .hue-who-row img',
      '#vk-photo-view .pv-c-av img',
      '#vk-photo-view .pv-who img',
      '#vk-photo-view .pv-write img',
      '#topbar-user img',
      '#mh-bar img',
      '.mh-user img',
      '.mh-user-av img',
      '.mh-notif-av img',
      '.vk-post-av img',
      '.vk-cmt-av img',
      '.vk-dlg-av img',
      '.vk-compose-av img',
      '.post-avatar img',
      '.author-avatar img',
      '.comment-avatar img',
      '.user-card img',
      // Картинки внутри ссылок на пользователей
      'a[href^="/id"] img',
      'a[href^="/@"] img',
      'a[href^="/user/"] img',
      // Общие аватарные классы и пути
      'img[class*="avatar"]',
      'img[class*="ava"]',
      'img[class*="userpic"]',
      'img[class*="photo"]:not(.pv-img):not(.gallery-photo)',
      'img[src*="avatar"]',
      'img[src*="user"]',
      'img[src*="/uploads/"]',
      'img.avatar',
      'img.ava'
    ];

    const imgs = document.querySelectorAll(imgAvatarSelectors.join(', '));
    imgs.forEach((img) => {
      if (img.classList.contains('fedor-icon') || img.hasAttribute('data-fedor-icon') || img.closest('.fedor-logo-wrap')) {
        return;
      }
      // Не заменять большие фотографии-вложения к записям
      if (img.closest('.post-attachments, .wall-photos, .photo-album, .gallery, .attachment, #pv-box')) {
        return;
      }

      if (img.src !== FEDOR_AVATAR_B64) {
        img.src = FEDOR_AVATAR_B64;
        if (img.srcset) img.srcset = '';
        if (img.hasAttribute('data-src')) img.setAttribute('data-src', FEDOR_AVATAR_B64);
        if (img.hasAttribute('data-original')) img.setAttribute('data-original', FEDOR_AVATAR_B64);
        img.setAttribute('data-fedor-avatar', 'true');
        img.classList.add('fedor-avatar');
        stats.avatarsReplaced++;
      }
    });

    // 6.2 Элементы div / span / a (с фоновым изображением и пустые заглушки без аватарок)
    const bgAvatarSelectors = [
      '.hue-av',
      '.hue-av-main',
      '.mh-user-av',
      '.mh-notif-av',
      '.hue-popup-av',
      '.cw-av',
      '.cw-mini-av',
      '.gcw-av',
      '.gcm-av',
      '.vk-person-av',
      '.vk-ava-round',
      '.vk-post-av',
      '.vk-cmt-av',
      '.vk-compose-av',
      '.vk-dlg-av',
      '.vk-chat-head-av',
      '.zv-abanner-av',
      '.zv-acard-av',
      '.zv-cform-av',
      '.zv-cmt-av',
      '.zv-person-av',
      '.zv-set-av',
      '.zv-atile-av',
      '.zv-newf-av',
      '.hue-sugg-av',
      '.hue-ms-av',
      '.dv-wh-av',
      '.dv-av',
      '.ac-noava',
      '.vk-grp-noav',
      '.vk-gp-noav',
      '.avatar',
      '.ava',
      '[class*="avatar"]',
      '[class*="ava"]',
      'a[href^="/id"][style*="background"]',
      'div[style*="background"]'
    ];

    const bgElements = document.querySelectorAll(bgAvatarSelectors.join(', '));
    bgElements.forEach((el) => {
      if (el.tagName === 'IMG') return;
      if (el.classList.contains('fedor-icon') || el.closest('.fedor-logo-wrap')) return;

      // Если это пустая заглушка с инициалами (например .ac-noava или .vk-grp-noav)
      if (el.classList.contains('ac-noava') || el.classList.contains('vk-grp-noav') || el.classList.contains('vk-gp-noav')) {
        el.style.color = 'transparent';
      }

      const currentBg = el.style.backgroundImage || '';
      if (!currentBg.includes(FEDOR_AVATAR_B64.slice(0, 40))) {
        el.style.backgroundImage = `url("${FEDOR_AVATAR_B64}")`;
        el.style.backgroundSize = 'contain';
        el.style.backgroundRepeat = 'no-repeat';
        el.style.backgroundPosition = 'center';
        el.setAttribute('data-fedor-avatar', 'true');
        stats.avatarsReplaced++;
      }
    });
  }

  // Регулярные выражения для фильтрации дат/чисел/служебных надписей
  const DATE_TIME_REGEX = /^(сегодня|вчера|\d+\s+(янв|фев|мар|апр|май|июн|июл|авг|сен|окт|ноя|дек)|\d{1,2}:\d{2}|\d+\s+(сек|мин|час|дн))/i;

  function setNicknameElement(el) {
    if (!el) return;

    // Не трогаем боковое меню, даты, время, служебные ссылки и логотипы
    if (el.closest('.fedor-logo-wrap, .post-date, .post-time, .comment-date, .comment-time, .sidebar-nav, #sidebar-nav')) {
      return;
    }

    const currentText = el.textContent.trim();
    if (!currentText || currentText === 'Федор Яйца') return;
    if (DATE_TIME_REGEX.test(currentText)) return;
    if (/^\+?\d+$/.test(currentText)) return; // Счетчики чисел (+1, 42)

    // Сохраняем бейджи (верификация, онлайн-точка и т.д.)
    const badge = el.querySelector('.verified, svg, [class*="verified"], [class*="badge"], .online, [class*="online"], .hue-vmark');
    const badgeClone = badge ? badge.cloneNode(true) : null;

    // Если внутри есть аватар или иконка, меняем только текстовые узлы
    if (el.querySelector('img, svg, .fedor-icon')) {
      let replaced = false;
      for (const node of Array.from(el.childNodes)) {
        if (node.nodeType === Node.TEXT_NODE && node.nodeValue.trim().length > 0) {
          if (!replaced) {
            node.nodeValue = ' Федор Яйца ';
            replaced = true;
          } else {
            node.nodeValue = '';
          }
        }
      }
      if (!replaced) {
        const innerTextEl = el.querySelector('.name, .author, span:not([class*="verified"]):not(.online):not(.fedor-icon):not(.hue-vmark), b, strong');
        if (innerTextEl && !innerTextEl.querySelector('img')) {
          innerTextEl.textContent = 'Федор Яйца';
          replaced = true;
        }
      }
    } else {
      // Обычный текстовый блок
      el.textContent = 'Федор Яйца';
      if (badgeClone) {
        el.appendChild(document.createTextNode(' '));
        el.appendChild(badgeClone);
      }
    }

    el.setAttribute('data-fedor-nick', 'true');
    stats.nicknamesReplaced++;
  }

  // 7. Замена всех никнеймов и авторов на «Федор Яйца»
  function transformNicknames() {
    if (!settings.enabled || !settings.changeNicknames) return;

    const nicknameSelectors = [
      // Шапка / юзернейм huEVO
      '#topbar-user a',
      '#topbar-user span',
      '.hm-user a',
      '.hm-user',
      '#mh-bar .mh-name',
      '#mh-bar .mh-user a',
      '#mh-bar .mh-user-name',
      '#mh-bar .mh-user span:not(.mh-user-av)',
      '.mh-user .name',
      // Имя профиля huEVO
      '.vk-page-user',
      'h1.profile-name',
      'h1.user-fullname',
      'h1.page-name',
      '.profile-title',
      '.user-name',
      '.owner-name',
      '#profile_name',
      '.page_name',
      '.profile-header h1',
      '.profile-header h2',
      // Посты на стене и в ленте huEVO
      '.vk-post-author',
      '.vk-post-author a',
      '.post-author',
      '.post-author a',
      '.post-header .author',
      '.post-header a.author',
      '.author-name',
      '.wall-author',
      '.post_author a',
      'a.author',
      '.post-title a[href^="/id"]',
      '.post-title a[href^="/@"]',
      // Комментарии huEVO
      '.vk-cmt-author',
      '.vk-cmt-author a',
      '.comment-author',
      '.comment-author a',
      '.comment-header .author',
      '.comment-header a',
      '.comm-author',
      '.comment_author a',
      // Темы и обсуждения
      '.vk-topic-author',
      '.mg-v-author',
      // Мессенджер / Диалоги huEVO
      '.vk-chat-name',
      '.vk-dlg-name',
      '.im-dialog-name',
      '.chat-peer-name',
      '.msg-author',
      '.chat-title',
      '.peer-title',
      '.im-log-author',
      // Списки друзей и пользователей huEVO
      '.vk-pick-who',
      '.user-card-name',
      '.friend-name',
      '.member-name',
      '.friends-name',
      // Ссылки на профили пользователей (/id* или /@*)
      'a[href^="/id"]:not([href="/"]):not([href^="/id0"])',
      'a[href^="/@"]',
      'a[href^="/user/"]'
    ];

    const elements = document.querySelectorAll(nicknameSelectors.join(', '));
    elements.forEach(setNicknameElement);
  }

  // Главная функция трансформации
  function applyFedorEVO() {
    if (!settings.enabled) return;

    try { transformLogo(); } catch (e) { console.error('[fedorEVO:logo]', e); }
    try { transformFavicon(); } catch (e) { console.error('[fedorEVO:favicon]', e); }
    try { transformSidebarCategories(); } catch (e) { console.error('[fedorEVO:sidebar]', e); }
    try { transformFeedTabs(); } catch (e) { console.error('[fedorEVO:tabs]', e); }
    try { transformGeneralIcons(); } catch (e) { console.error('[fedorEVO:icons]', e); }
    try { transformAvatars(); } catch (e) { console.error('[fedorEVO:avatars]', e); }
    try { transformNicknames(); } catch (e) { console.error('[fedorEVO:nicknames]', e); }
  }

  // Дебаунс для оптимизации MutationObserver
  let isTicking = false;
  function scheduleApply() {
    if (!isTicking) {
      isTicking = true;
      requestAnimationFrame(() => {
        applyFedorEVO();
        isTicking = false;
      });
    }
  }

  // Отслеживаем любые динамические изменения страницы (SPA/PJAX/комментарии)
  const observer = new MutationObserver(() => {
    scheduleApply();
  });

  // Запуск
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      loadSettings();
      observer.observe(document.body, { childList: true, subtree: true });
    });
  } else {
    loadSettings();
    observer.observe(document.body, { childList: true, subtree: true });
  }

  // Периодическая легкая проверка для надежности (раз в 1 секунду)
  setInterval(() => {
    if (settings.enabled) {
      applyFedorEVO();
    }
  }, 1000);

  console.log('[fedorEVO] Плагин «Федор Яйца» активирован!');
})();
