/**
 * fedorEVO - Popup Logic
 */

document.addEventListener('DOMContentLoaded', () => {
  const toggleEnabled = document.getElementById('toggle-enabled');
  const toggleCategories = document.getElementById('toggle-categories');
  const toggleIcons = document.getElementById('toggle-icons');
  const toggleAvatars = document.getElementById('toggle-avatars');
  const toggleNicknames = document.getElementById('toggle-nicknames');
  const toggleLogo = document.getElementById('toggle-logo');
  const toggleFavicon = document.getElementById('toggle-favicon');
  const statusBox = document.getElementById('fedor-status-box');
  const btnReload = document.getElementById('btn-reload-page');

  const defaultSettings = {
    enabled: true,
    changeCategories: true,
    changeIcons: true,
    changeAvatars: true,
    changeNicknames: true,
    changeLogo: true,
    changeFavicon: true
  };

  // Загружаем настройки
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['fedor_settings'], (res) => {
      const s = Object.assign({}, defaultSettings, res.fedor_settings || {});
      toggleEnabled.checked = s.enabled;
      toggleCategories.checked = s.changeCategories;
      toggleIcons.checked = s.changeIcons;
      toggleAvatars.checked = s.changeAvatars;
      toggleNicknames.checked = s.changeNicknames;
      toggleLogo.checked = s.changeLogo;
      toggleFavicon.checked = s.changeFavicon;
      updateStatus(s.enabled);
    });
  }

  function saveSettings() {
    const s = {
      enabled: toggleEnabled.checked,
      changeCategories: toggleCategories.checked,
      changeIcons: toggleIcons.checked,
      changeAvatars: toggleAvatars.checked,
      changeNicknames: toggleNicknames.checked,
      changeLogo: toggleLogo.checked,
      changeFavicon: toggleFavicon.checked
    };

    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ fedor_settings: s });
    }
    updateStatus(s.enabled);
  }

  function updateStatus(enabled) {
    if (enabled) {
      statusBox.textContent = '✓ Режим «Федор Яйца» активен';
      statusBox.style.color = '#FF7777';
      statusBox.style.borderColor = 'rgba(230, 34, 34, 0.4)';
    } else {
      statusBox.textContent = '✗ Плагин приостановлен';
      statusBox.style.color = '#969CA5';
      statusBox.style.borderColor = 'rgba(150, 156, 165, 0.2)';
    }
  }

  // Слушатели переключателей
  [toggleEnabled, toggleCategories, toggleIcons, toggleAvatars, toggleNicknames, toggleLogo, toggleFavicon].forEach((el) => {
    el.addEventListener('change', saveSettings);
  });

  // Кнопка перезагрузки страницы huEVO
  if (btnReload) {
    btnReload.addEventListener('click', () => {
      if (typeof chrome !== 'undefined' && chrome.tabs) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const tab = tabs[0];
          if (tab && tab.id) {
            chrome.tabs.reload(tab.id);
            window.close();
          }
        });
      } else {
        window.location.reload();
      }
    });
  }
});
